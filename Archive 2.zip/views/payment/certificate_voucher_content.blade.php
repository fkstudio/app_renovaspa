@extends('layout/baseLayout')

@section('title', 'Voucher')

@section("content")
	@include('payment._certificate_voucher')
@endsection
