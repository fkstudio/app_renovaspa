<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Bookhere Language Lines
    |--------------------------------------------------------------------------
    */

    'book_title': 'Book your treatment',
    'info': 'Online Booking receives 10% discount'

];
