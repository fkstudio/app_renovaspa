<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Navbar Language Lines
    |--------------------------------------------------------------------------
    */

    'home' => 'HOME',
    'bookhere' => 'BOOK HERE',
    'gift_certificates' => 'GIFT CERTIFICATES',
    'weddings' => 'WEDDINGS',
    'the_day' => "THE DAY",
    'faqs' => 'FAQS',
    'destinations' => 'DESTINATIONS',
    'about_us' => 'ABOUT US',
    'contact_us' => 'CONTACT US',
    'lang' => 'LANG',
    'es' => 'ESP',
    'en' => 'ENG'

];
