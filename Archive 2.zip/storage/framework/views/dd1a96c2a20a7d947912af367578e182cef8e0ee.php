<?php $__env->startSection('title', 'Card information'); ?>

<?php $__env->startSection("content"); ?>
	<div class="container-fluid">
		<div class="container">
			<p class="message-alert success">PLEASE WAIT A MOMENT, WE ARE PROCEDING TO CHECKOUT.</p>
			<hr/>
			<div class="row hidden">
				<form name="paymentForm" action="<?php echo e($url); ?>" method="POST" >
					<div class="">
						<input type="hidden" name="Ds_SignatureVersion" value="<?php echo e($version); ?>"/>
					</div>
					<div class="">
						<input type="hidden" name="Ds_MerchantParameters" value="<?php echo e($params); ?>"/>
					</div>
					<div class="">
						<input type="hidden" name="Ds_Signature" value="<?php echo e($signature); ?>"/>
					</div>
					<div class="">
						<button style="visibility:hidden;" type="submit"></button>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
	document.paymentForm.submit();
</script>
<?php $__env->stopSection(); ?>


	
<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>