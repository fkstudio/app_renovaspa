<?php if(session('success')): ?>
<p class="message-alert success"><?php echo e(session('success')); ?></p>
<?php endif; ?>

<?php if(session('failure')): ?>
<p class="message-alert failure"><?php echo e(session('failure')); ?></p>
<?php endif; ?>