<?php

return [

    /*
    |--------------------------------------------------------------------------
    | reservation checkout view Language Lines
    |--------------------------------------------------------------------------
    */

    'booked_to' => 'Booked to',
    'at_time' => 'at time',
    'place_order' => 'PLACE ORDER'

];
