<?php

return [

    /*
    |--------------------------------------------------------------------------
    | reservation checkout view Language Lines
    |--------------------------------------------------------------------------
    */

    'booked_to' => 'Booked to',
    'at_time' => 'at time',
    'place_order' => 'PLACE ORDER',
    'message' => 'Message',
    'value' => 'Value',
    'not_my_info' => 'This is not my information. I am making this purchase for another person.',
    'upon_availability' => '*Upon availability'

];
