<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Gift Language Lines
    |--------------------------------------------------------------------------
    */

    'title': 'Treat someone',
    'info': '10% off on service based or 10% bonus on value based gift certificates'

];
