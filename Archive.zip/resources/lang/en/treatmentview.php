<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Treatment view Language Lines
    |--------------------------------------------------------------------------
    */

    'not_suitable' => 'Not suitable during pregnancy',
    'suitable_minors' => 'Suitable for minors',
    'tax_included' => 'Prices include 16.00% tax'

];
