<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Bookhere Language Lines
    |--------------------------------------------------------------------------
    */

    'online_discount_reservation' => 'Online Booking receives 10% discount',
    'online_certificate_discount_reservation' => '10% off on service based or 10% bonus on value based gift certificates'

];
