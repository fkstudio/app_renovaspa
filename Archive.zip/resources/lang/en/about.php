<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Hotel details Language Lines
    |--------------------------------------------------------------------------
    */

    'about'=> 'ABOUT US',
    'our_history' => 'OUR HISTORY',
    'history' => 'Inspired by the Ideologies of the Ancient that believes Beauty Health and Spirit is an inseparable unit, the Renova Spa core purpose is the total and complete wellbeing of our clients. Each of our experience is unique in an authentic surrounding create for encourage the rejuvenation and revitalization of the Beauty, Health and Spirit in an authentic surrounding of peace and comfort. Highly trained and dedicated spa therapist offer a variety of treatment through options of body and beauty care with the highest SPA products as Payot, L’Oreal, OPI and more. Our broad services Menu, includes services for specific need and personalized preferences.',
    'our_values' => 'OUR VALUES',
    'philosophy_title' => 'PHILOSOPHY',
    'philosophy_text' => 'The Renova SPA is a collection of unique Spas with worldwide presence, associated of premier-lever Resorts and City Hotels. Featured in 10 Countries across 4 Continents with more than 50 Spas, Renova SPA will transform a wonderful vacation or a business trip in an unforgettable experience. Drawing from a depth of spa knowledge and teaching beginning in 1997 in the Dominican Republic, Puerto Plata, Renova SPA expanded then in Mexico, Jamaica, Bahamas, Cape Verde, Canary Island (Spain), Panama and Costa Rica, Aruba, Saint Martin, Mauritius and Sri Lanka.
		Throughout the company’s expansion, his mandate was strengthened ever more: anticipate the needs and desires of the travelers delighting each sense with natural ingredients and enhance centuries old treatments to provide a unique spa experience.',
	'our_mission_title'=> 'OUR MISSION',
	'our_mission_text'=> 'At Renova SPA our commitment is to create authentic experiences for the total relaxation of our guests during their vacation. Our SPAs are comfortable and sensorial, created with a total respect of the environment. Each one unique in its style but with an evident Renova SPA touch. While Renova SPA offers different treatments throughout the world, the menu of each SPA is tailored to the Resort’s theme, design and clientele. Programs are thoughtfully designed to luxuriously pamper and indulge, heal and nourish, restore and rejuvenate . To meet our guest’s expectations and achieve their total satisfaction, Renova SPA is governed by four important values applied in all the different destinations: <br/><br/><br/>


•Respect and Responsabilities Towards every person (guest or staff) and towards the environment. THESE TWO values are the basis for a harmonious coexistence with each other and with our surrounding.<br/><br/>
• Honesty and Integrity in everything we do. In the services that we offer and how we treat each other.
• Be creative and innovative Always at the forefront in treatment techniques and products dor the perfect balance among beauty helth and spirit.<br/><br/>
• Staff Recognition. Renova SPA recognizes its employees as a key ingredient for the ongoing success of the Company. For this reason we strain to hire people from the local community and train them according to the corporate plan in order to benefit them personally and professionally.' 


];
