<?php

return [

    /*
    |--------------------------------------------------------------------------
    | titles view Language Lines
    |--------------------------------------------------------------------------
    */

    'service_list_title' => 'Select your moment of pleasure',
    'my_cart_title' => 'SHOPPING CART SERVICES',
    'cart_checkout_title' => 'CHECKOUT ITEMS',
    'reservation_checkout_customer_title' => 'CUSTOMER INFORMATION',
    'reservation_checkout_left_title' => 'BILLING INFORMATION',
    'reservation_checkout_right_title' => 'ORDER SUMMARY',
    'cart_total' => 'CART TOTAL',
    'card_info' => 'CREDIT CARD INFORMATION',
    'book_your_treatment' => 'BOOK YOUR TREATMENT',
    'treat_someone' => 'TREAT SOMEONE',
    'the_day' => 'THE DAY',
    'wedding_reservation' => 'RESERVATION FORM FOR WEDDINGS'

];
