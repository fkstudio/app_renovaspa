<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Hotel details Language Lines
    |--------------------------------------------------------------------------
    */

    'address' => 'Address',
    'hours' => 'Hours',
    'spa_facilities' => 'Spa facilities',
    'services_and_prices' => 'Services and prices',
    'want_to_book' => 'Want to book?'

];
