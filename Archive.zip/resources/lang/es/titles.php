<?php

return [

    /*
    |--------------------------------------------------------------------------
    | titles view Language Lines
    |--------------------------------------------------------------------------
    */

    'service_list_title' => 'Select your moment of pleasure',
    'my_cart_title' => 'SERVICIOS EN EL CARRITO DE COMPRAS',
    'cart_checkout_title' => 'PROCEDER A RESERVAR',
    'reservation_checkout_customer_title' => 'INFORMACIÓN DEL CLIENTE',
    'reservation_checkout_left_title' => 'INFORMACIÓN DE FACTURACIÓN',
    'reservation_checkout_right_title' => 'RESUMEN DE COMPRA',
    'cart_total' => 'TOTAL DE COMPRA',
    'card_info' => 'INFORMACIÓN DE TARJETA',
    'book_your_treatment' => 'RESERVA TU TRATAMIENTO',
    'treat_someone' => 'RESERVA PARA ALGUIEN',
    'the_day' => 'THE DAY'

];
