<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Hotel details Language Lines
    |--------------------------------------------------------------------------
    */

    'address' => 'Dirección',
    'hours' => 'Horario',
    'spa_facilities' => 'Facilidades del spa',
    'services_and_prices' => 'Servicios y precios',
    'want_to_book' => 'Deseas reservar?'

];
