<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Navbar Language Lines
    |--------------------------------------------------------------------------
    */

    'home' => 'INICIO',
    'bookhere' => 'RESERVAR',
    'gift_certificates' => 'CERTIFICADOS',
    'weddings' => 'BODAS',
    'the_day' => "EL DIA",
    'faqs' => 'FAQS',
    'destinations' => 'DESTINOS',
    'about_us' => 'SOBRE NOSOTROS',
    'contact_us' => 'CONTACTANOS',
    'lang' => 'LANG',
    'es' => 'ESP',
    'en' => 'ENG'

];
