<?php if(isset($mycart)): ?>
<!-- Modal -->
<div id="shoppingCartModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><?php echo e(trans('titles.my_cart_title')); ?></h4>
      </div>
      <div class="modal-body">
        <?php 
          $subtotal = 0;
          $total = 0;
         ?>

        <?php $__currentLoopData = $mycart->Items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <!-- individual services -->
          <?php if($item->Service != null && $item->CertificateNumber == null): ?>
            <div class="col-md-3">
              <img style="max-width: 80px;" src="<?php echo e(URL::to('/')); ?>/images/services/collagen-puls-facial.jpg" class="img-responsive" /> 
            </div>
            <div class="col-md-9">
              <h5><?php echo e($item->Service->Name); ?></h5>
              <?php echo e(trans("shared.cabin_type")); ?> ( <?php echo e($item->Service->Cabin->Name); ?> )
              <br/>
              <?php 
                $itemPrice = $item->Service->getPrice(session('hotel_id'));

                $subtotal += $item->Service->getPlanePrice(session('hotel_id'));
                $total += $itemPrice;
               ?>
              <span><?php echo e(trans('shared.price')); ?>: <?php echo e($country->Currency->Symbol); ?><?php echo e(number_format($itemPrice, 2)); ?> <?php echo e($country->Currency->Name); ?></span>
            </div>
            <div class="clearfix"></div>
            <br/>
          <!-- Certificate services -->
          <?php elseif($item->CertificateNumber != null): ?>
            <div class="col-md-3">
              <img style="max-width: 80px;" src="<?php echo e(URL::to('/')); ?>/images/services/collagen-puls-facial.jpg" class="img-responsive" /> 
            </div>
            <div class="col-md-9">
              <h5><?php echo e($item->Service->Name); ?> - Certificate #<?php echo e($item->CertificateNumber); ?></h5>
              <?php echo e(trans("shared.cabin_type")); ?> ( <?php echo e($item->Service->Cabin->Name); ?> )
              <br/>
              <?php 
                $itemPrice = $item->Service->getPrice(session('hotel_id'));

                $subtotal += $item->Service->getPlanePrice(session('hotel_id'));
                $total += $itemPrice;
               ?>
              <span><?php echo e(trans('shared.price')); ?>: <?php echo e($country->Currency->Symbol); ?><?php echo e(number_format($item->Service->getPrice(session('hotel_id')), 2)); ?> <?php echo e($country->Currency->Name); ?></span>
            </div>
            <div class="clearfix"></div>
            <br/>
          <!-- wedding packages -->
          <?php else: ?>
            <?php 
              $packageRelation = $item->PackageCategoryRelation;
              $itemPrice = $packageRelation->Price;
             ?>

            <div class="col-md-3">
              <img style="max-width: 80px;" src="<?php echo e(URL::to('/')); ?>/images/wedding_package_icon.png" class="img-responsive" /> 
            </div>
            <div class="col-md-9">
              <h5><?php echo e($packageRelation->WeddingPackage->Name); ?></h5>
              
              <?php $__currentLoopData = $packageRelation->WeddingPackage->WeddingPackageServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packageService): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <?php 
                  $subtotal += $itemPrice;
                  $total += $itemPrice;
                 ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              <span><?php echo e(trans('shared.price')); ?>: <?php echo e($country->Currency->Symbol); ?><?php echo e(number_format($itemPrice, 2)); ?> <?php echo e($country->Currency->Name); ?></span>
            </div>

            <div class="clearfix"></div>
            <br/>
          <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      <div class="clearfix"></div>
      <hr/>
      <table class="table table-borderless">
        <h4><?php echo e(trans('titles.cart_total')); ?></h4>
        <tbody style="font-size: 15px;">
          <tr>
            <td>Subtotal</td>
            <td><?php echo e($country->Currency->Symbol); ?><?php echo e(number_format($subtotal, 2)); ?></td>
          </tr>
          <?php if($hotel_region->ActiveDiscount): ?>
          <tr>
            <td><span style="font-size: 15px;font-weight: bold;" class="discount">-<?php echo e($hotel_region->Discount); ?>% <?php echo e(trans('shared.online_discount_available')); ?></span></td>
          </tr>
          <?php endif; ?>
          <tr>
            <td><strong>Total</strong></td>
            <td><strong><?php echo e($country->Currency->Symbol); ?><?php echo e(number_format($total, 2)); ?></strong></td>
          </tr>
        </tbody>
      </table>
      </div>
      <div class="modal-footer">
        <a href="<?php echo e(URL::to('/')); ?>/shopping/cart" class="btn btn-default" ><?php echo e(trans('shared.go_to_cart')); ?></a>
        <a href="<?php echo e(URL::to('/')); ?>/shopping/cart/checkout" class="btn btn-primary" ><?php echo e(trans('shared.checkout')); ?></a>
      </div>
    </div>

  </div>
</div>
<?php endif; ?>