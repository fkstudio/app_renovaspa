<?php 
  $reservationType = session('reservation_type');
 ?>
<?php if(isset($mycart)): ?>
<!-- Modal -->
<div id="shoppingCartModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><?php echo e(trans('titles.my_cart_title')); ?></h4>
      </div>
      <div class="modal-body">
        <?php 
          $subtotal = 0;
          $total = 0;
         ?>

        <?php if(count($mycart->Items) <= 0): ?>
        <p style="text-align: center;"><?php echo e(trans('messages.there_is_no_items_in_cart')); ?></p>
        <?php endif; ?>

        <?php $__currentLoopData = $mycart->Items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <!-- individual services -->
          <?php if($item->Service != null && $item->CertificateNumber == null): ?>
            <div class="col-md-3">
              <img style="max-width: 80px;" src="<?php echo e(URL::to('/')); ?>/images/services/collagen-puls-facial.jpg" class="img-responsive" /> 
            </div>
            <div class="col-md-9">
              <h5><?php echo e($item->Service->Name); ?></h5>
              <?php echo e(trans("shared.cabin_type")); ?> ( <?php echo e($item->Service->Cabin->Name); ?> )
              <br/>
              <?php 
                $itemPrice = $item->Service->getPrice(session('hotel_id'));
                $itemPlanePrice = $item->Service->getPlanePrice(session('hotel_id'));
                $subtotal += $itemPlanePrice;
                $total += $itemPrice;
               ?>
              <span><?php echo e(trans('shared.price')); ?>: <?php echo e($country->Currency->Symbol); ?><?php echo e(number_format($itemPlanePrice, 2)); ?> <?php echo e($country->Currency->Name); ?></span>
              <br/>
              <span><?php echo e(trans('shared.final_price')); ?>: <?php echo e($country->Currency->Symbol); ?><?php echo e(number_format($itemPrice, 2)); ?> <?php echo e($country->Currency->Name); ?></span>
            </div>
            <div class="clearfix"></div>
            <br/>
          <!-- Certificate services -->
          <?php elseif($item->CertificateNumber != null): ?>
            <div class="col-md-3">
              <img style="max-width: 80px;" src="<?php echo e(URL::to('/')); ?>/images/services/collagen-puls-facial.jpg" class="img-responsive" /> 
            </div>
            <div class="col-md-9">
              <h5>
              <?php echo e(( $item->Service != null ? $item->Service->Name . ' - ' : '' )); ?> Certificate #<?php echo e($item->CertificateNumber); ?>

              </h5>
              <?php if($item->Service != null): ?>
              <?php echo e(trans("shared.cabin_type")); ?> ( <?php echo e($item->Service->Cabin->Name); ?> )
              <?php else: ?>
              ( Value based )
              <?php endif; ?>
              <br/>
              <?php 
                if($item->Service != null){
                  $itemPrice = $item->Service->getPrice(session('hotel_id'));

                  $subtotal += $item->Service->getPlanePrice(session('hotel_id'));
                  $total += $itemPrice;
                }
                else {
                  $itemPrice = $item->Value;

                  $subtotal += $item->Value;
                  $total += $itemPrice;
                }
               ?>
              <span><?php echo e(trans('shared.price')); ?>: <?php echo e($country->Currency->Symbol); ?><?php echo e(number_format($itemPrice, 2)); ?> <?php echo e($country->Currency->Name); ?></span>
            </div>
            <div class="clearfix"></div>
            <br/>
          <!-- wedding packages -->
          <?php else: ?>
            <?php 
              $packageRelation = $item->PackageCategoryRelation;
              $itemPrice = $packageRelation->getPrice();
             ?>

            <div class="col-md-3">
              <img style="max-width: 80px;" src="<?php echo e(URL::to('/')); ?>/images/wedding_package_icon.png" class="img-responsive" /> 
            </div>
            <div class="col-md-9">
              <h5><?php echo e($packageRelation->WeddingPackage->Name); ?></h5>
              
              <?php $__currentLoopData = $packageRelation->WeddingPackage->WeddingPackageServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packageService): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <?php 
                  $subtotal += $itemPrice;
                  $total += $itemPrice;
                 ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              <span><?php echo e(trans('shared.price')); ?>: <?php echo e($country->Currency->Symbol); ?><?php echo e(number_format($itemPrice, 2)); ?> <?php echo e($country->Currency->Name); ?></span>
            </div>

            <div class="clearfix"></div>
            <br/>
          <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      <div class="clearfix"></div>
      <hr/>
      <table class="table table-borderless">
        <h4><?php echo e(trans('titles.cart_total')); ?></h4>
        <tbody style="font-size: 15px;">
          <tr>
            <td>Subtotal</td>
            <td><?php echo e($country->Currency->Symbol); ?><?php echo e(number_format($subtotal, 2)); ?></td>
          </tr>
          <?php if($hotel_region->ActiveDiscount): ?>
          <tr>
            <td><span style="font-size: 15px;font-weight: bold;" class="discount">-<?php echo e($hotel_region->Discount); ?>% <?php echo e(trans('shared.online_discount_available')); ?></span></td>
          </tr>
          <?php endif; ?>
          <tr>
            <td><strong>Total</strong></td>
            <td><strong><?php echo e($country->Currency->Symbol); ?><?php echo e(number_format($total, 2)); ?></strong></td>
          </tr>
        </tbody>
      </table>
      </div>
      <div class="modal-footer">
        <?php if($reservationType == 1 || $reservationType == 3 || session('current_certificate') >= session('certificate_quantity') && session('can_go_to_cart') == true): ?>
        <a href="<?php echo e(URL::to('/shopping/cart')); ?>" class="btn btn-default"><?php echo e(trans('shared.go_to_cart')); ?></a>
        <?php elseif($reservationType == 1 || session('current_certificate') >= session('certificate_quantity') && session('can_go_to_cart') == false): ?>
        <a href="#fakelink" class="disabled btn btn-default"><?php echo e(trans('shared.complete_to_go_cart')); ?></a>
        <?php else: ?>
        <a href="<?php echo e(URL::to('/')); ?>/hotel/<?php echo e($hotel->Id); ?>/categories/<?php echo e(session('current_certificate') + 1); ?>" class="btn btn-default"><?php echo e(trans('shared.go_to_next_certificate')); ?></a>
        <?php endif; ?>

        <?php if($reservationType == 1 || $reservationType == 3): ?> 
          <?php if($total > 0): ?>
            <a href="<?php echo e(URL::to('/')); ?>/shopping/cart/checkout" class="btn btn-primary" ><?php echo e(trans('shared.checkout')); ?></a>
          <?php else: ?>
            <a href="<?php echo e(URL::to('/')); ?>/shopping/cart/checkout" class="disabled btn btn-primary" ><?php echo e(trans('shared.checkout')); ?></a>
          <?php endif; ?>

        <?php elseif($reservationType == 2): ?>
          <?php if($total > 0): ?>
            <a href="<?php echo e(URL::to('/')); ?>/certificate/registration" class="btn btn-primary" ><?php echo e(trans('shared.go_to_gift_registration')); ?></a>
          <?php else: ?>
            <a href="<?php echo e(URL::to('/')); ?>/certificate/registration" class="disabled btn btn-primary" ><?php echo e(trans('shared.go_to_gift_registration')); ?></a>
          <?php endif; ?>
        
        <?php endif; ?>
      </div>
    </div>

  </div>
</div>
<?php endif; ?>