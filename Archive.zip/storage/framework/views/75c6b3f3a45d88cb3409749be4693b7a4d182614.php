<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
	<div class="container-fluid-full">
		<ul class="bxslider">
		  <li><img title="RELAX MODE" src="<?php echo e(URL::to('/')); ?>/images/carousel/facial_treatment.jpg" /></li>
		  <li><img src="<?php echo e(URL::to('/')); ?>/images/carousel/body_treatment.jpg" /></li>
		  <li><img src="<?php echo e(URL::to('/')); ?>/images/carousel/wedding_treatment.jpg" /></li>
		</ul>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Moment JS-->
<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>

<!-- Include Date Range Picker -->
<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />

<!-- bxSlider CSS file -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bxslider/4.2.9/jquery.bxslider.min.css" rel="stylesheet" />

<!-- bxSlider Javascript file -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bxslider/4.2.9/jquery.bxslider.min.js"></script>
<script>
	function adjustSize(){
		var height = $(window).height();  //getting windows height
		$('.bx-viewport').css('height',height+'px');   //and setting height of 
	}

	$(document).ready(function(){
		$('.bxslider').bxSlider({
		  auto: true,
		  mode: 'fade',
		  speed: 700,
		  captions: true,
		  easing : [ 'linear', 'ease', 'ease-in', 'ease-out', 'ease-in-out', 'cubic-bezier(n,n,n,n)' ]
		});

		adjustSize();

		$(window).resize(function(){
			console.log('w');
			adjustSize();
		})
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>