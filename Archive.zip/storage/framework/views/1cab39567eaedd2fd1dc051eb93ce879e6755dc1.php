<?php $dbcontext = app('App\Database\DbContext'); ?>



<?php $__env->startSection('title', 'Wedding services'); ?>

<?php $__env->startSection("content"); ?>
<div id="vue-app" class="container-fluid">
	<?php echo $__env->make('shared._breadcrumps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<hr>
	<h3 class="green-title"><?php echo e(trans('titles.wedding_reservation')); ?></h3>
	<br/>
	<p><strong><?php echo e(trans('wedding.important')); ?>:</strong> <?php echo e(trans('wedding.you_will_be_contacted')); ?></p>
	<form action="<?php echo e(URL::to('/')); ?>/wedding/send/quotation" method="POST">
		<div class="col-md-12">
			<div class="row">
				<div class="row">
					<div class="col-md-12">
						<h3><?php echo e(trans('wedding.personal_info')); ?></h3>
						<div class="clearfix"></div>
						<hr />
						<?php echo $__env->make('shared._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
					<div class="clearfix"></div>
					<br/>
					<div class="col-md-3">
						<div class="form-group">
							<input type="text" required name="first_name" value="<?php echo e($model->CertificateFirstName); ?>" class="form-control input-border" placeholder="* First name">
						</div>
					</div>
					<div class="col-md-3">
						<div class="form-group">
							<input type="text" required name="last_name" value="<?php echo e($model->CertificateLastName); ?>" class="form-control input-border" placeholder="* Last name">
						</div>
					</div>
					<div class="clearfix"></div>
					<div class="col-md-3">
						<div class="form-group">
							<input type="email" required name="email" value="<?php echo e($model->Email); ?>" class="form-control input-border" placeholder="* Email">
						</div>
					</div>
					<div class="col-md-3">
						<div class="form-group">
							<input type="email" required name="email_confirmation" class="form-control input-border" placeholder="* Email confirmation">
						</div>
					</div>
					<div class="col-md-12">
						<h3><?php echo e(trans('wedding.couple_info')); ?></h3>
						<div class="clearfix"></div>
						<hr />
					</div>
					
					<div class="col-md-3">
						<div class="form-group">
							<input type="text" required name="bride_full_name" class="form-control input-border" value="<?php echo e($model->BrideName); ?>" placeholder="* Bride full name">
						</div>
					</div>
					<div class="col-md-3">
						<div class="form-group">
							<input type="text" required name="groom_full_name" class="form-control input-border" value="<?php echo e($model->GroomName); ?>" placeholder="* Groom full name">
						</div>
					</div>

					<div class="col-md-12">
						<h3><?php echo e(trans('wedding.reservation_info')); ?></h3>
						<div class="clearfix"></div>
						<hr />
					</div>
					<div class="clearfix"></div>
					<div class="col-md-2">
						<label><?php echo e(trans('shared.country')); ?></label>
						<br/>
						<span><?php echo e($model->Region->Country->Name); ?></span>
					</div>
					<div class="col-md-2">
						<label><?php echo e(trans('shared.destination')); ?></label>
						<br/>
						<span><?php echo e($model->Region->Name); ?></span>
					</div>
					<div class="col-md-2">
						<label><?php echo e(trans('shared.hotel')); ?></label>
						<br/>
						<span><?php echo e($model->Hotel->Name); ?></span>
					</div>
					<div class="clearfix"></div>
					<br/>
					<div class="col-md-3">
						<label>(*) <?php echo e(trans('wedding.wedding_date')); ?></label>
						<br/>
						<p>We only take reservations within 6 months prior to the wedding date and not before.</p>
						<input type="text" name="wedding_date" class="datepicker form-control input-border" />
						<br/>
						<label>(*) <?php echo e(trans('wedding.wedding_time')); ?></label>
						<br/>
						<input type="text" value="<?php echo e(( $model->WeddingTime != null ? $model->WeddingTime->format('h:m a') : '' )); ?>" name="wedding_time" class="timepicker form-control input-border" />
					</div>
				</div>
				
			</div>
		</div>
		<div class="clearfix"></div>
		<h3 class="green-title"><?php echo e(trans('wedding.quotation')); ?></h3>
		<br/>
		<h3><?php echo e(trans('wedding.service_info')); ?></h3>
		<hr/>
		<div class="row">
			<?php $__currentLoopData = $cart->Items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<?php 
					$packageRelation = $item->PackageCategoryRelation;
				 ?>
				<?php if($item->Service != null): ?>
					<div class="col-md-12">
						<h5>1 <?php echo e($item->Service->Name); ?> - <?php echo e(trans("shared.cabin_type")); ?> ( <?php echo e($item->Service->Cabin->Name); ?> )</h5>
						<span><?php echo e(trans('checkout.booked_to')); ?> <?php echo e($item->PreferedDate->format('d/m/Y')); ?> <?php echo e(trans('checkout.at_time')); ?> <?php echo e($item->PreferedTime->format('h:m a')); ?>, <?php echo e($item->CustomerName); ?></span>
					</div>
					<div class="clearfix"></div>
					<hr/>
				<?php else: ?>
					<?php $__currentLoopData = $packageRelation->WeddingPackage->WeddingPackageServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packageService): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<div class="col-md-12">
							<h5>1 <?php echo e(( $packageRelation != null ? $packageRelation->WeddingPackage->Name . ' - ' : '').$packageService->Service->Name); ?> - <?php echo e(trans("shared.cabin_type")); ?> ( <?php echo e($packageService->Service->Cabin->Name); ?> )</h5>
							<span><?php echo e(trans('checkout.booked_to')); ?> <?php echo e($item->PreferedDate->format('d/m/Y')); ?> <?php echo e(trans('checkout.at_time')); ?> <?php echo e($item->PreferedTime->format('h:m a')); ?>, <?php echo e($item->CustomerName); ?></span>
						</div>
						<div class="clearfix"></div>
						<hr/>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				<?php endif; ?>

				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</div>
		<h3>CART TOTAL</h3>
		<table style="font-size: 20px;" class="table table-borderless">
			<?php 
				$hotel_region = $dbcontext->getEntityManager()->getRepository("App\Models\Test\HotelRegionModel")->findOneBy([ 'Hotel' => session('hotel_id'), 'Region' => session('region_id') ]);
			 ?>
			<tbody>
				<tr>
					<td>Subtotal</td>
					<td><span class="pull-right"><?php echo e($model->Region->Country->Currency->Symbol); ?><?php echo e($model->Subtotal); ?></span></td>
				</tr>
				<?php if($hotel_region->ActiveDiscount): ?>
				<tr>
					<td>
					<span style="font-size: 15px;font-weight: bold;" class="discount">-<?php echo e($hotel_region->Discount); ?>% <?php echo e(trans('shared.online_discount_available')); ?></span></td>
				</tr>
				<?php endif; ?>
				<tr>
					<td><strong>Total</strong></td>
					<td><strong class="pull-right"><?php echo e($model->Region->Country->Currency->Symbol); ?><?php echo e($model->Total); ?></strong></td>
				</tr>
			</tbody>
		</table>
		<hr/>
		<a href="<?php echo e(URL::to('/')); ?>/hotel/<?php echo e($hotel_region->Hotel->Id); ?>/categories"><?php echo e(trans('messages.would_you_like')); ?></a>
		<hr/>
		<p style="color: red;"><strong>50% down payment will be required by the wedding concierge in order to confirm this reservation once this request has been checked out and approved within the next 24 hours For any questions, please, contact: info@renovaspa.com</strong></p>
		<hr/>
		<h3><?php echo e(trans('wedding.payment_info')); ?></h3>
		<hr>
		<p><?php echo e(trans('wedding.would_you_like')); ?></p>
		<div class="col-md-7">
			<div class="row">
				<select name="bill_delivery" class="form-control custom-select">
					<option value="1">-- Select an option --</option>
					<option value="2">Send one bill including all the services.</option>
					<option value="3">Send one bill including the wedding couples services and other for each person of the wedding party</option>
					<option value="4">Send separate bills for each person.</option>
				</select>
				<label>Remarks</label>
				<br>
				<p><?php echo e(trans('wedding.aditional_request')); ?></p>
				<textarea name="remarks" rows="10" resizable='false' class="form-control input-border"><?php echo e($model->Remarks); ?></textarea>
				<hr>
				<?php echo e(csrf_field()); ?>

				<button type="submit" class="btn btn-primary"><?php echo e(trans('wedding.send_reservation_form')); ?></button>
				<a href="<?php echo e(URL::to('/')); ?>/reservation/canceled" class="btn btn-danger"><?php echo e(trans('wedding.cancel')); ?></a>
			</div>
			
		</div>
	</form>	
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Moment JS-->
<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>


<!-- Timepicker -->
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/')); ?>/css/jquery.timepicker.css">
<script type="text/javascript" src="<?php echo e(URL::to('/')); ?>/js/jquery.timepicker.js"></script>

<!-- Include Date Range Picker -->
<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />

<script>
	$(function() {
	    $('.datepicker').daterangepicker({
	        minDate: moment().add(2, "days"),
	        singleDatePicker: true,
	        showDropdowns: true,
	        
		});

		$('.timepicker').timepicker();
	});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>