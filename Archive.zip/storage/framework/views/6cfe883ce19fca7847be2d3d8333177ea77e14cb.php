<?php $__env->startSection('title', 'Complete certificate information'); ?>

<?php $dbcontext = app('App\Database\DbContext'); ?>

<?php 
	$country = $dbcontext->getEntityManager()->getRepository("App\Models\Test\CountryModel")->findOneBy([ 'Id' => session('country_id') ]);

	$symbol = $country->Currency->Symbol;
 ?>

<?php $__env->startSection("content"); ?>
<div id="vue-app" class="container-fluid">
	<div class="container">
		<h3 class="green-title">GIFT CERTIFICATE REGISTRATION</h3>
		<br/>
		<form action="<?php echo e(URL::to('/')); ?>/reservation/checkout" method="POST">
			<div class="row">
				<div class="col-md-4">
					<div class="form-group">
						<label>A) Who will receive this gift certificate?</label>
					</div>
					<div class="form-group">
						<label class="custom-label">* First name</label>
						<input type="text" class="form-control input-border" name="first_name" />
					</div>
					<div class="form-group">
						<label class="custom-label">* Last name</label>
						<input type="text" class="form-control input-border" name="last_name" />
					</div>
				</div>
			</div>

			<div class="clearfix"></div>
			<hr class="custom-hr" > 
			
			<div class="form-group">
				<label>B) Personalize by adding a message:</label>
			</div>
			<?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<h3>Certificate #<?php echo e($item->CertificateNumber); ?></h3>
			<hr>
			<strong>Value: <?php echo e($symbol.$item->Value); ?></strong>
			<hr>
			<a href="#fakelink">Edit </a> <a href="#fakelink"> Delete</a>
			<hr>	
			<div class="row">
				<div class="col-md-8">
					<div class="form-group">
						<input type="hidden" class="form-control input-border" name="certificate_number[<?php echo e($key); ?>]" value="<?php echo e($key); ?>" />
					</div>

					<div class="form-group">
						<div class="row">
							<div class="col-md-6">
								<label class="custom-label">* To (as it will appear on the gift certificate):</label>
								<input type="text" class="form-control input-border" name="to_customer[<?php echo e($key); ?>]" />
							</div>
							<div class="col-md-6">
								<label class="custom-label">* From (as it will appear on the gift certificate):</label>
								<input type="text" class="form-control input-border" name="from_customer[<?php echo e($key); ?>]" />
							</div>	
							<div class="clearfix"></div>
							<br/>
							<div class="col-md-12">
								<div class="form-group">
									<label class="custom-label">Enter a message</label>
									<textarea  name="message[<?php echo e($key); ?>]" class="form-control input-border"></textarea>
								</div>
							</div>	
						</div>
					</div>
					<div class="form-group">
						<label>C) Select delivery method:</label>
						<p>* Choose from Renova Spa s flexible delivery options</p>
					</div>
					<div class="clearfix"></div>
					<br/>
					<div class="col-md-4 delivery-type-content">
						<span style="font-size: 30px;margin-left: 12px" class="glyphicon glyphicon-envelope"></span>
						<br/>
						<input type="radio" name="sendType[<?php echo e($key); ?>]" value=1 > Email
						<br/>
						<p>Instantly send it to the recipient's e-mail.</p>
					</div>
					<div class="col-md-4 delivery-type-content">
						<span style="font-size: 30px;margin-left: 12px" class="glyphicon glyphicon-print"></span>
						<br/>
						<input type="radio" name="sendType[<?php echo e($key); ?>]" value=2 > Print
						<br/>
						<p>Receive the gift certificate in your mail and print it off.</p>
					</div>
					<div class="col-md-4 delivery-type-content">
						<span style="font-size: 30px;margin-left: 12px" class="glyphicon glyphicon-home"></span>
						<br/>
						<input type="radio" name="sendType[<?php echo e($key); ?>]" value=3 > Hotel
						<br/>
						<p>Let us deliver your certificate at your recipient's hotel room*.</p>
					</div>
				</div>

			</div>

			
			<div class="clearfix"></div>
			<hr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			<div class="col-md-12 certificate-terms">
				<p> <input type="checkbox" name="terms"><?php echo e(trans('shared.certificate_terms')); ?></p>
			</div>
			<div class="col-md-3">
				<div class="row">
					<?php echo e(csrf_field()); ?>

					<button type="submit" class="btn btn-primary">CONTINUE</button>
				</div>
			</div>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(URL::to('/js')); ?>/vuejs.js"></script>
<script>
    $(document).ready(function(){
        var vue = new Vue({
            el: '#vue-app',
            data: {
               quantity: 0,
               type: 1,
               value_based: [ ]
            },
            ready: function(){
            },
            computed: {

            },
            methods: {
                add_certificate(){
                	this.value_based = [];
                	for($i = 1; $i <= this.quantity; $i++){
                		this.value_based.push({ value: 0 });
                	}
                }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>