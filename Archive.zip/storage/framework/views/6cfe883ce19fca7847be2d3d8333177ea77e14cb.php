<?php $__env->startSection('title', 'Complete certificate information'); ?>

<?php $dbcontext = app('App\Database\DbContext'); ?>

<?php 
	$country = $dbcontext->getEntityManager()->getRepository("App\Models\Test\CountryModel")->findOneBy([ 'Id' => session('country_id') ]);

	$symbol = $country->Currency->Symbol;
 ?>

<?php $__env->startSection("content"); ?>
<div id="vue-app" class="container-fluid">
	<div class="container">
		<h3 class="green-title">GIFT CERTIFICATE REGISTRATION</h3>
		<p id="errorMessageContent" class="message-alert failure" style="display:none;">Please fill all fields and accept the terms.</p>
		<br/>
		<form onsubmit="return validateTerms()" action="<?php echo e(URL::to('/')); ?>/reservation/checkout" method="POST">
			<?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<h3>Certificate #<?php echo e($item->CertificateNumber); ?></h3>
			<br/>
			<div class="form-group">
				<label>A) Personalize by adding a message:</label>
			</div>
			<hr>
			<strong style="font-size:18px;">Value: <?php echo e($symbol.$item->Value); ?></strong>
			<hr>
			<div class="row">
				<div class="col-md-8">
					<div class="form-group">
						<input type="hidden" class="form-control input-border" name="certificate_number[<?php echo e($key); ?>]" value="<?php echo e($key); ?>" />
					</div>

					<div class="form-group">
						<div class="row">
							<div class="col-md-6">
								<label>* To (as it will appear on the gift certificate):</label>
								<input type="text" class="required-input form-control input-border" name="to_customer[<?php echo e($key); ?>]" />
							</div>
							<div class="col-md-6">
								<label>* From (as it will appear on the gift certificate):</label>
								<input type="text" class="required-input form-control input-border" name="from_customer[<?php echo e($key); ?>]" />
							</div>	
							<div class="clearfix"></div>
							<br/>
							<div class="col-md-12">
								<div class="form-group">
									<label>Enter a message</label>
									<textarea  name="message[<?php echo e($key); ?>]" class="form-control input-border"></textarea>
								</div>
							</div>	
						</div>
					</div>
					<div class="form-group">
						<label>B) Select delivery method:</label>
						<p>* Choose from Renova Spa s flexible delivery options</p>
					</div>
					<div class="clearfix"></div>
					<br/>
					<div class="col-md-4 delivery-type-content">
						<span style="font-size: 30px;margin-left: 12px" class="glyphicon glyphicon-envelope"></span>
						<br/>
						<input class="collapse-button" data-toggle="collapse" data-target="#certificate-<?php echo e($key); ?>-email" type="radio" name="sendType[<?php echo e($key); ?>]" value=1 ><br/> Email
						<br/>
						<p>Instantly send it to the recipient's e-mail.</p>
					</div>
					<div class="col-md-4 delivery-type-content">
						<span style="font-size: 30px;margin-left: 12px" class="glyphicon glyphicon-print"></span>
						<br/>
						<input class="collapse-button" data-toggle="collapse" data-target="#certificate-<?php echo e($key); ?>-print" type="radio" name="sendType[<?php echo e($key); ?>]" value=2 ><br/> Print
						<br/>
						<p>Receive the gift certificate in your mail and print it off.</p>
					</div>
					<div class="col-md-4 delivery-type-content">
						<span style="font-size: 30px;margin-left: 12px" class="glyphicon glyphicon-home"></span>
						<br/>
						<input class="collapse-button" data-toggle="collapse" data-target="#certificate-<?php echo e($key); ?>-hotel" type="radio" name="sendType[<?php echo e($key); ?>]" value=3 ><br/> Hotel
						<br/>
						<p>Let us deliver your certificate at your recipient's hotel room*.</p>
					</div>
				</div>
				<div class="clearfix"></div>
				<div id="certificate-<?php echo e($key); ?>-email" class="collapse col-md-12">
					<hr>
					<label>D) Enter delivery information</label>
					<p>Please provide the recipient's email addres</p>
					<div class="clearfix"></div>
					<div class="col-md-4">
						<div class="row">
							<table class="table table-responsive">
								<tbody>
									<tr>
										<td>
											<label>E-mail</label>
										</td>
										<td>
											<input type="email" name="delivery_email[<?php echo e($key); ?>]" class="form-control input-border" />
										</td>
									</tr>
									<tr>
										<td>
											<label>E-mail confirmation</label>
										</td>
										<td>
											<input type="email" name="delivery_email_confirmation[<?php echo e($key); ?>]" class="form-control input-border" />
										</td>
									</tr>
								</tbody>
							</table>	
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
				<div id="certificate-<?php echo e($key); ?>-print" class="collapse col-md-12">
					<hr>
					<p><strong>NOTA:</strong><br/>Your gift certificates will be sent to your e-mail account as soon as your order is complete.</p>
				</div>
				<div class="clearfix"></div>
				<div id="certificate-<?php echo e($key); ?>-hotel" class="collapse col-md-12">
					<hr>
					<label>D) Enter delivery information</label>
					<p><strong>Important notes:</strong></p>
					<ul>
						<li>Certificates will be delivered only in hotels that have a Renova Spa.</li>
						<li>Certificates will be delivered at the recipient's room by Renova Spa within 12 hours after arrival, not at the hotel check-in.</li>
						<li>Certificated to be delivered for guests staying at the hotel by the time of purchase may need up to 24 hours for delivery.</li>
					</ul>
					<br/>
					<p><strong>Completing the following information will facilitate the location of the guest. Please provide at least one of the following:</strong></p>
					<br/>
					<div class="clearfix"></div>
					<div class="col-md-7">
						<div class="row">
							<table class="table table-responsive">
								<tbody>
									<tr>
										<td>
											<label>Hotel reservation number or travel agency</label>
										</td>
										<td>
											<input type="text" name="delivery_number_or_agency[<?php echo e($key); ?>]" class="form-control input-border" />
										</td>
									</tr>
									<tr>
										<td>
											<label>Companion name</label>
										</td>
										<td>
											<input type="text" name="delivery_company_name[<?php echo e($key); ?>]" class="form-control input-border" />
										</td>
									</tr>
									<tr>
										<td>
											<label>Departure date</label>
										</td>
										<td>
											<input type="text" name="delivery_departure_date[<?php echo e($key); ?>]" class="form-control input-border" />
										</td>
									</tr>
									<tr>
										<td>
											<label>Other information</label>
										</td>
										<td>
											<input type="text" name="delivery_other_info[<?php echo e($key); ?>]" class="form-control input-border" />
										</td>
									</tr>
								</tbody>
							</table>
						</div>	
					</div>
				</div>
			</div>

			
			<div class="clearfix"></div>
			<hr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			<div class="col-md-12 certificate-terms">
				<p> <input type="checkbox" id="accept_terms" name="terms"><?php echo e(trans('shared.certificate_terms')); ?></p>
			</div>
			<div class="col-md-3">
				<div class="row">
					<?php echo e(csrf_field()); ?>

					<button type="submit" class="btn btn-primary">CONTINUE</button>
				</div>
			</div>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(URL::to('/js')); ?>/vuejs.js"></script>
<script>
	function validateTerms(){
		var pass = true;

		if (!$("#accept_terms").is(":checked")) {
			pass = false;
	    }

	    var requiredInputs = $('.required-input');

	    $.each(requiredInputs, function(key, value){
	    	if($(value).val() == "")
	    		pass = false;
	    });

	    
	    if(!pass){
	    	$("#errorMessageContent").fadeTo(2000, 500).slideUp(500, function(){
	            $("#errorMessageContent").slideUp(500);
	        });
	    }
	    return pass;
	}

    $(document).ready(function(){
        // hidden all collapse when 1 collapse is clicked and then open it
        $('.collapse-button').on('click', function () {
		  $('.collapse').collapse('hide')
		})
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>