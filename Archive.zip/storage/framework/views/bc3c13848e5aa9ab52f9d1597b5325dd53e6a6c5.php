<?php $dbcontext = app('App\Database\DbContext'); ?>



<?php $__env->startSection('title', 'Services'); ?>

<?php 

  $categories = $dbcontext->getEntityManager()->getRepository("App\Models\Test\CategoryCountryModel")
                                                  ->findBy(["Country" => session('country_id')], ["Order" => "DESC"]);

  $hotel_region = $dbcontext->getEntityManager()->getRepository("App\Models\Test\HotelRegionModel")->findOneBy([ 'Hotel' => session('hotel_id'), 'Region' => session('region_id') ]);

 ?>

<?php $__env->startSection("content"); ?>
	<div class="container-fluid">
		<?php echo $__env->make('shared._breadcrumps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<hr>
		<?php echo $__env->make('shared._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="row">
			<br/>
			<div class="col-lg-4 col-md-12 col-sm-12">
				<?php if($category->Photo != null): ?>
				<img style="margin: 0 auto;" src="<?php echo e(URL::to('/images/categories')); ?>/category-<?php echo e($category->Id); ?>/<?php echo e($category->Photo->Path); ?>" class="img-responsive" alt='<?php echo e($category->Name); ?>' />
				<?php endif; ?>
				<br class="hidden-lg" />
				<p class="text-center">
					<a href="#fakelink" style="color:#5fc7ae;">+Info</a>
				</p>
			</div>
			<div class="col-lg-8 col-md-12 col-sm-12">
				<h4><?php echo e(trans('titles.service_list_title')); ?></h5>
				<br/>
				<form action="<?php echo e(URL::to('/')); ?>/cart/add/services" method="POST">
					<?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $serviceCategoryHotelModel): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<?php 
						$serviceInformation = $serviceCategoryHotelModel->ServiceInformation;
					 ?>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
							<label>Service</label>
							<br/>
							<?php echo e($serviceCategoryHotelModel->Service->Name); ?> <a href="#fakelink" data-toggle="collapse" data-target="#service-<?php echo e($key); ?>" style="color:#5fc7ae;">+info</a>
							<input type="hidden" name="id[]" value="<?php echo e($serviceCategoryHotelModel->Service->Id); ?>" /> 
						</div>
						<div class="col-lg-2 col-md-2 hidden-sm hidden-xs">
							<label>Duration</label>
							<br/>
							<?php echo e($serviceInformation->Duration); ?>

						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 hidden-xs">
							<?php if($serviceCategoryHotelModel->Service->hasDiscount($hotel->Id)): ?>
								<?php 
									$discount = $serviceCategoryHotelModel->Service->getDiscount($hotel->Id)
								 ?>
							<span class="discount"><?php echo e("-".$discount. "% ".trans('shared.discount')); ?></span>
							<?php endif; ?>

							<?php if($serviceCategoryHotelModel->Service->hasHotelDiscount($hotel->Id)): ?>
							<span class="discount">-<?php echo e($hotel_region->Discount); ?>% <?php echo e(trans('shared.online_discount')); ?></span>
							<?php elseif($hotel_region->ActiveDiscount): ?>
							<span class="discount-tached">-<?php echo e($hotel_region->Discount); ?>% <?php echo e(trans('shared.online_discount')); ?></span>
							<?php endif; ?>
						</div>
						<div class="col-lg-1 col-md-1 col-sm-2 col-xs-4">
							<label>Price</label>
							<br/>
							<?php echo e($region->Country->Currency->Symbol.number_format($serviceCategoryHotelModel->Service->getPrice($hotel->Id), 2)); ?>

						</div>
						<div class="col-lg-2 col-md-2 col-sm-2 col-xs-4">
							<label>Quantity</label>
							<br/>
							<input style="max-width: 70px !important;" type="number" value='0' name="quantity[]" class="input-border input-cart" />
						</div>
						<div class="clearfix"></div>
						<div class="col-md-12 collapse" id="service-<?php echo e($key); ?>">
							<hr/>
							<strong>Description:</strong>
							<blockquote>
								<?php echo e($serviceInformation->Description); ?>

							</blockquote>
							<strong>Schedules:</strong>
							<blockquote>
								From <?php echo e($serviceInformation->OpeningTime->format('h:m a')); ?> to <?php echo e($serviceInformation->EndingTime->format('h:m a')); ?>

							</blockquote>
							<strong>Restrictions:</strong>
							<blockquote>
								Pregnant restriction: <?php echo e(($serviceInformation->PregnantRestriction == true ? 'Yes' : 'No')); ?>

								<br/>
								Age restriction: <?php echo e(( $serviceInformation->AgeRestriction == true ? 'Yes' : 'No')); ?>

							</blockquote>
							<hr/>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					<div class="clearfix"></div>
					<br/>
					<?php if(count($model) <= 0): ?>
					<p style="text-align: center;"><?php echo e(trans('messages.there_is_no_items_to_show')); ?></p>
					<br/>
					<?php endif; ?>
					<div class="clearfix"></div>
					<div class="form-group">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<?php echo e(csrf_field()); ?>

								<button type="submit" name="services" class="btn btn-interline block-button"><?php echo e(trans('shared.add_to_cart')); ?></button>	
							</div>
							<div class="clearfix visible-xs"></div>
							<br class="visible-xs" />
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<?php if(session('reservation_type') == 1 || session('reservation_type') == 3 || session('current_certificate') >= session('certificate_quantity') && session('can_go_to_cart') == true): ?>
								<a href="<?php echo e(URL::to('/shopping/cart')); ?>" class="btn btn-default block-button"><?php echo e(trans('shared.go_to_cart')); ?></a>
								<?php elseif(session('reservation_type') == 1 || session('current_certificate') >= session('certificate_quantity') && session('can_go_to_cart') == false): ?>
								<a href="#fakelink" class="disabled btn btn-default block-button"><?php echo e(trans('shared.complete_to_go_cart')); ?></a>
								<?php else: ?>
								<a href="<?php echo e(URL::to('/')); ?>/hotel/<?php echo e($hotel->Id); ?>/categories/<?php echo e(session('current_certificate') + 1); ?>" class="btn btn-default block-button"><?php echo e(trans('shared.go_to_next_certificate')); ?></a>
								<?php endif; ?>	
								
								 
							</div>
						</div>
					</div>	
				</form>
				
			</div>
			<div class="clearfix"></div>
			<div class="col-lg-4"></div>
			<div class="col-lg-4"></div>
			<div class="col-lg-4">
				<p class="text-center">Prices include 16.00 % tax</p>
			</div>
		</div>
	</div>
	<br/>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>