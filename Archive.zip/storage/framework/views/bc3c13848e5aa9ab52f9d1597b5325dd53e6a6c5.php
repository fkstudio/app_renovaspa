<?php $dbcontext = app('App\Database\DbContext'); ?>



<?php $__env->startSection('title', 'Services'); ?>

<?php 

  $categories = $dbcontext->getEntityManager()->getRepository("App\Models\Test\CategoryCountryModel")
                                                  ->findBy(["Country" => session('country_id')], ["Order" => "DESC"]);

  $hotel_region = $dbcontext->getEntityManager()->getRepository("App\Models\Test\HotelRegionModel")->findOneBy([ 'Hotel' => session('hotel_id'), 'Region' => session('region_id') ]);

 ?>

<?php $__env->startSection("content"); ?>
	<div class="container-fluid">
		<?php echo $__env->make('shared._breadcrumps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<hr>
		<?php echo $__env->make('shared._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="row">
			<br/>
			<div class="col-md-5">
				<?php if($category->Photo != null): ?>
				<img style="margin: 0 auto;" src="<?php echo e(URL::to('/images/categories')); ?>/category-<?php echo e($category->Id); ?>/<?php echo e($category->Photo->Path); ?>" class="img-responsive" alt='<?php echo e($category->Name); ?>' />
				<?php endif; ?>
				<br class="hidden-lg" />
			</div>
			<div class="col-md-7">
				<h4><?php echo e(trans('titles.service_list_title')); ?></h5>
				<form action="<?php echo e(URL::to('/')); ?>/cart/add/services" method="POST">
					<table class="table table-responsive table-borderless">
						<thead>
							<tr>
								<th><?php echo e(trans('shared.service')); ?></th>
								<th></th>
								<th></th>
								<th><?php echo e(trans('shared.price')); ?></th>
								<th><?php echo e(trans('shared.quantity')); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryRegion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
							<tr>
								<td>
									<input type="hidden" name="id[]" value="<?php echo e($categoryRegion->Service->Id); ?>" /> 
									<?php echo e($categoryRegion->Service->Name); ?> +info
								</td>
								<td></td>
								<td>
									<?php if($categoryRegion->Service->hasDiscount($hotel->Id)): ?>
										<?php 
											$discount = $categoryRegion->Service->getDiscount($hotel->Id)
										 ?>
									<span class="discount"><?php echo e("-".$discount. "% ".trans('shared.discount')); ?></span>
									<?php endif; ?>

									<?php if($categoryRegion->Service->hasHotelDiscount($hotel->Id)): ?>
									<span class="discount">-<?php echo e($hotel_region->Discount); ?>% <?php echo e(trans('shared.online_discount')); ?></span>
									<?php elseif($hotel_region->ActiveDiscount): ?>
									<span class="discount-tached">-<?php echo e($hotel_region->Discount); ?>% <?php echo e(trans('shared.online_discount')); ?></span>
									<?php endif; ?>
									
								</td>
								<td><?php echo e($region->Country->Currency->Symbol.number_format($categoryRegion->Service->getPrice($hotel->Id))); ?></td>
								<td>
									<input style="max-width: 70px !important;" type="number" value='0' name="quantity[]" class="form-control input-border" />
								</td>
							</tr>
						    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
						</tbody>
					</table>
					<?php if(count($model) <= 0): ?>
					<p style="text-align: center;">There is not item at your cart</p>
					<br/>
					<?php endif; ?>
					<div class="clearfix"></div>
					<div class="form-group">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<?php echo e(csrf_field()); ?>

								<button type="submit" name="services" class="btn btn-interline block-button"><?php echo e(trans('shared.add_to_cart')); ?></button>	
							</div>
							<br class="visible-xs" />
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<?php if(session('reservation_type') == 1 || session('current_certificate') >= session('certificate_quantity') && session('can_go_to_cart') == true): ?>
								<a href="<?php echo e(URL::to('/shopping/cart')); ?>" class="btn btn-default block-button"><?php echo e(trans('shared.go_to_cart')); ?></a>
								<?php elseif(session('reservation_type') == 1 || session('current_certificate') >= session('certificate_quantity') && session('can_go_to_cart') == false): ?>
								<a href="#fakelink" class="disabled btn btn-default block-button">COMPLETE TO VIEW THE CART</a>
								<?php else: ?>
								<a href="<?php echo e(URL::to('/')); ?>/hotel/<?php echo e($hotel->Id); ?>/categories/<?php echo e(session('current_certificate') + 1); ?>" class="btn btn-default block-button">GO TO NEXT CERTIFICATE</a>
								<?php endif; ?>	
								
								 
							</div>
						</div>
					</div>	
				</form>
				
			</div>
		</div>
	</div>
	<br/>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>