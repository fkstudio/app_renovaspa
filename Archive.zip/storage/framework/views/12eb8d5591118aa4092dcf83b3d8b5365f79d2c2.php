	

	<?php $__env->startSection('title', 'Checkout'); ?>

	<?php $__env->startSection("content"); ?>
		<div class="container-fluid">
			<?php echo $__env->make('shared._breadcrumps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<hr/>
			<h3><?php echo e(trans('titles.cart_checkout_title')); ?></h3>
			<hr>
			<div class="row">
				<br/>
				<div class="col-md-12">
					<p id="errorMessageContent" class="message-alert failure" style="display:none;">Please fill all fields and accept the terms.</p>
				    <?php echo $__env->make('shared._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<form onsubmit="return validateTerms()" action="<?php echo e(URL::to('/')); ?>/reservation/checkout" method="post">
						<table class="table table-responsive">
							<thead>
								<tr>
									<th><?php echo e(trans('shared.service')); ?></th>
									<th><?php echo e(trans('shared.customer_name')); ?></th>
									<th><?php echo e(trans('shared.prefered_date')); ?></th>
									<th><?php echo e(trans('shared.prefered_time')); ?></th>
									<th><?php echo e(trans('shared.cabin_type')); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $model->Items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
									<?php if($item->Service != null): ?>
										<?php 
											$serviceCabin = $item->Service->Cabin;
										 ?>
										<tr>
											<td class="padding-td">
												<input type="hidden" name="id[]" value="<?php echo e($item->Id); ?>" /> 
												<?php echo e(($item->PackageCategoryRelation != null ? $item->PackageCategoryRelation->WeddingPackage->Name.' - ' : '' ) . $item->Service->Name); ?>

											</td>
											<td class="padding-td">
												<?php 
													$parts = explode(", ", $item->CustomerName);
												 ?>

												<?php if($serviceCabin->Name == "Single"): ?>
													<input type="text" required name="customer_name[<?php echo e($key); ?>][]" placeholder="Complete name..." class="form-control required-input" value="<?php echo e($parts[0]); ?>" />
												<?php elseif($serviceCabin->Name == "Double"): ?>
													<input type="text" required name="customer_name[<?php echo e($key); ?>][]" placeholder="Complete name..." class="form-control required-input" value="<?php echo e((isset($parts[0]) ? $parts[0] : '')); ?>" />
													<input type="text" required name="customer_name[<?php echo e($key); ?>][]" placeholder="You will shared room with..." class="form-control required-input" value="<?php echo e((isset($parts[1]) ? $parts[1] : '' )); ?>" />
												<?php elseif($serviceCabin->Name == "Package"): ?>
													<?php for($i = 0; $i < $serviceCabin->MaxCantPersons; $i ++): ?>
														<input type="text" required name="customer_name[<?php echo e($key); ?>][]" placeholder="Complete name..." class="form-control required-input" value="<?php echo e((isset($parts[$i]) ? $parts[$i] : '' )); ?>" />
													<?php endfor; ?>
												<?php endif; ?>
											</td>
											<td class="padding-td">
												<input type="text" name="prefered_date[]" value="<?php echo e(( $item->PreferedDate != null ? $item->PreferedDate->format('mm/dd/yyyy') : '' )); ?>" class="datepicker form-control required-input" />
											</td>
											<td class="padding-td">
												<input type="text" name="prefered_time[]" value="<?php echo e(( $item->PreferedTime != null ? $item->PreferedTime->format('h:m') : '12:00pm' )); ?>" class="timepicker form-control required-input" />
											</td>
											
											<td class="padding-td">
												<?php if($item->Service->Cabin->Name != "Package"): ?>
												<select class="form-control required-input blank-select" name="cabin_type[]">
													<?php $__currentLoopData = $cabins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cabin): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
														<?php if($cabin->Name != "Package"): ?>
															<?php if($item->Service != null && $item->Service->Cabin->Id == $cabin->Id): ?>
																<option selected value="<?php echo e($cabin->Id); ?>" ><?php echo e($cabin->Name); ?></option>
															<?php else: ?> 
																<option value="<?php echo e($cabin->Id); ?>" ><?php echo e($cabin->Name); ?></option>
															<?php endif; ?>
														<?php endif; ?>
													
													<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
												</select>
												<?php else: ?>
												<select type="text" name="cabin_type[]" readonly class="disabled custom-select form-control required-input">
													<option value="<?php echo e($item->Service->Cabin->Id); ?>"><?php echo e($item->Service->Cabin->Name); ?></option>
												</select>
												<?php endif; ?>
											</td>
										</tr>
									<?php else: ?>
										<?php 
											$packageRelation = $item->PackageCategoryRelation;
											$packageFeatures = $packageRelation->WeddingPackage->WeddingPackageFeatures;
										 ?>
										
										<?php $__currentLoopData = $packageFeatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
											<tr>
												<td><?php echo e($feature->Description); ?></td>
												<td>--</td>
												<td>--</td>
												<td>--</td>
												<td>--</td>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

										<?php $__currentLoopData = $packageRelation->WeddingPackage->WeddingPackageServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skey => $weddingPackageService): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
											<?php 
														$serviceCabin = $weddingPackageService->Service->Cabin;
													 ?>
													<tr>
														<td class="padding-td">
															<input type="hidden" name="id[]" value="<?php echo e($item->Id); ?>" /> 
															<?php echo e(($packageRelation != null ? $packageRelation->WeddingPackage->Name.' - ' : '' ) .$weddingPackageService->Service->Name); ?>

														</td>
														<td class="padding-td">
															<?php 
																$parts = explode(", ", $item->CustomerName);
															 ?>

															<?php if($serviceCabin->Name == "Single"): ?>
																<input type="text" required name="customer_name[<?php echo e($skey); ?>][]" placeholder="Complete name..." class="form-control required-input" value="<?php echo e($parts[0]); ?>" />
															<?php elseif($serviceCabin->Name == "Double"): ?>
																<input type="text" required name="customer_name[<?php echo e($skey); ?>][]" placeholder="Complete name..." class="form-control required-input" value="<?php echo e((isset($parts[0]) ? $parts[0] : '')); ?>" />
																<input type="text" required name="customer_name[<?php echo e($skey); ?>][]" placeholder="You will shared room with..." class="form-control required-input" value="<?php echo e((isset($parts[1]) ? $parts[1] : '' )); ?>" />
															<?php elseif($serviceCabin->Name == "Package"): ?>
																<?php for($i = 0; $i < $serviceCabin->MaxCantPersons; $i ++): ?>
																	<input type="text" required name="customer_name[<?php echo e($skey); ?>][]" placeholder="Complete name..." class="form-control required-input" value="<?php echo e((isset($parts[$i]) ? $parts[$i] : '' )); ?>" />
																<?php endfor; ?>
															<?php endif; ?>
														</td>
														<td class="padding-td">
															<input type="text" name="prefered_date[]" value="<?php echo e(( $item->PreferedDate != null ? $item->PreferedDate->format('mm/dd/yyyy') : '' )); ?>" class="datepicker form-control required-input" />
														</td>
														<td class="padding-td">
															<input type="text" name="prefered_time[]" value="<?php echo e(( $item->PreferedTime != null ? $item->PreferedTime->format('h:m') : '12:00pm' )); ?>" class="timepicker form-control required-input" />
														</td>
														
														<td class="padding-td">
															<?php if($weddingPackageService->Service->Cabin->Name != "Package"): ?>
															<select class="form-control required-input blank-select" name="cabin_type[]">
																<?php $__currentLoopData = $cabins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cabin): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
																	<?php if($cabin->Name != "Package"): ?>
																		<?php if($weddingPackageService->Service != null && $weddingPackageService->Service->Cabin->Id == $cabin->Id): ?>
																			<option selected value="<?php echo e($cabin->Id); ?>" ><?php echo e($cabin->Name); ?></option>
																		<?php else: ?> 
																			<option value="<?php echo e($cabin->Id); ?>" ><?php echo e($cabin->Name); ?></option>
																		<?php endif; ?>
																	<?php endif; ?>
																
																<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
															</select>
															<?php else: ?>
															<select type="text" name="cabin_type[]" readonly class="disabled custom-select form-control required-input">
																<option value="<?php echo e($weddingPackageService->Service->Cabin->Id); ?>"><?php echo e($weddingPackageService->Service->Cabin->Name); ?></option>
															</select>
															<?php endif; ?>
														</td>
													</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
								
							</tbody>
						</table>
						<div class="clearfix"></div>
						<div class="col-lg-4 col-lg-offset-8">
							<h4 class="pull-right"><?php echo e(trans('checkout.upon_availability')); ?></h4>
							<div class="clearfix"></div>
							<p class="pull-right">
								<input type="checkbox" id="accept_terms" name="accept_terms">
								<a href="#fakielink">I have added a spa service and I agree...</a>
							</p>	
						</div>
						<div class="clearfix"></div>
						<div class="form-group pull-right">
							<?php echo e(csrf_field()); ?>

							<a href="<?php echo e(URL::to('/')); ?>/shopping/cart" class="btn btn-default"><?php echo e(trans('shared.back_to_cart')); ?></a>
							<?php if(count($model->Items) > 0): ?>
								<button type="submit" class="btn btn-primary"><?php echo e(trans('shared.procced_to_payment')); ?></button>
							<?php else: ?>
								<button type="button" class="disabled btn btn-primary"><?php echo e(trans('shared.procced_to_payment')); ?></button>
							<?php endif; ?>
						</div>	
					</form>
				</div>
			</div>
		</div>
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('scripts'); ?>
	<!-- Moment JS-->
	<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>

	<!-- Timepicker -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/')); ?>/css/jquery.timepicker.css">
	<script type="text/javascript" src="<?php echo e(URL::to('/')); ?>/js/jquery.timepicker.js"></script>

	<!-- Include Date Range Picker -->
	<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
	<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />

	<script>
		function validateTerms(){
			var pass = true;

			if (!$("#accept_terms").is(":checked")) {
				pass = false;
		    }

		    var requiredInputs = $('.required-input');

		    $.each(requiredInputs, function(key, value){
		    	if($(value).val() == "")
		    		pass = false;
		    });

		    
		    if(!pass){
		    	$("#errorMessageContent").fadeTo(2000, 500).slideUp(500, function(){
		            $("#errorMessageContent").slideUp(500);
		        });
		    }
		    return pass;
		}

		$(function() {
		    $('.datepicker').daterangepicker({
		    	locale: {
			      format: 'MM/D/YYYY'
			    },
		        minDate: moment().add(2, "days"),
		        singleDatePicker: true,
		        showDropdowns: true,
		        
			});

			$('.timepicker').timepicker();
		});
	</script>
	<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>