<?php $dbcontext = app('App\Database\DbContext'); ?>
<nav class="navbar top-menu">
  <div class="container-fluid">
    <div class="collapse navbar-collapse navbar-right" id="navbar">
        <ul class="nav navbar-nav">
          <li><a href="#fakelink">(829) 837-1892</a></li>
          <li><a href="#fakelink">info@renovaspa.com</a></li>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e(trans('navbar.lang')); ?> <span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="<?php echo e(url('/')); ?>/setlang/es"><?php echo e(trans('navbar.es')); ?></a></li>
              <li><a href="<?php echo e(url('/')); ?>/setlang/en"><?php echo e(trans('navbar.en')); ?></a></li>
            </ul>
          </li>
        </ul>
      </div>
  </div>
</nav>
<nav class="navbar navbar-default" data-spy="affix" data-offset-top="36">
  <div class="container-fluid">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="navbar" aria-expanded="false">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="<?php echo e(URL::to('/')); ?>">
          <img class="img-responsive" style="margin-top: -17px;" src="<?php echo e(URL::to('/')); ?>/images/logo-white-bg.png">
        </a>
      </div>

      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse navbar-right" id="navbar">
        <ul class="nav navbar-nav">
          <li><a href="<?php echo e(route('home.home')); ?>"><?php echo e(trans('navbar.home')); ?> <span class="sr-only">(current)</span></a></li>
          <li><a href="<?php echo e(URL::to('/')); ?>/select/services"><?php echo e(trans('navbar.bookhere')); ?></a></li>
          <li><a href="<?php echo e(URL::to('/')); ?>/select/certificates"><?php echo e(trans('navbar.gift_certificates')); ?></a></li>
          <li class="dropdown">
            <a href="#fakelink" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e(trans('navbar.weddings')); ?> <span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="<?php echo e(URL::to('/')); ?>/select/weddings"><?php echo e(trans('navbar.the_day')); ?></a></li>
              <li><a href="#"><?php echo e(trans('navbar.faqs')); ?></a></li>
            </ul>
          </li>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e(trans('navbar.destinations')); ?> <span class="caret"></span></a>
              <ul class="dropdown-menu" style="width: 300px"> 
                <?php $__currentLoopData = $dbcontext->getEntityManager()->getRepository("App\Models\Test\CountryModel")->findAll(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li class="dropdown-submenu">
                  <a href="#fakelink" tabindex="-1" class="dropdown-submenu-item"><?php echo e($country->Name); ?> <span class="caret"></span></a>
                  <ul class="dropdown-submenu">
                    <?php $__currentLoopData = $country->Regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                      <a href="#fakelink" tabindex="-1" class="dropdown-submenu-item"><?php echo e($region->Name); ?> <span class="caret"></span></a>
                      <ul class="dropdown-submenu">
                        <?php $__currentLoopData = $region->HotelRegions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotelRegion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                          <li><a href="<?php echo e(URL::to('/')); ?>/hotel/details/<?php echo e($hotelRegion->Hotel->Id); ?>" tabindex="-1" class="dropdown-submenu-item"><?php echo e($hotelRegion->Hotel->Name); ?> <span class="caret"></span></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                      </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                  </ul>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?> 
              </ul>
          </li>
          <li><a href="<?php echo e(route('home.about')); ?>"><?php echo e(trans('navbar.about_us')); ?></a></li>
          <li><a href="#"><?php echo e(trans('navbar.contact_us')); ?></a></li>
        </ul>
      </div>

      <!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<?php if(isset($categories)): ?>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="collapse navbar-collapse navbar-right" id="navbar">
        <ul class="nav navbar-nav">
          <?php if(session('reservation_type') == 3): ?>
          <li><a href="<?php echo e(URL::to('/')); ?>/wedding/services">RENOVA WEDDING PACKAGE</a></li>
          <?php endif; ?>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryRegion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <li><a href="<?php echo e(URL::to('/')); ?>/category/<?php echo e($categoryRegion->Category->Id); ?>/services"><?php echo e($categoryRegion->Category->Name); ?></a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
      </div>
  </div>
</nav>
<?php endif; ?>
