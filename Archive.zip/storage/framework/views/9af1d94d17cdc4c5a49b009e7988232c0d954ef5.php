<?php $dbcontext = app('App\Database\DbContext'); ?>


<nav class="navbar top-menu">
  <div class="container-fluid">
    <div class="collapse navbar-collapse navbar-right" id="navbar">
        <ul class="nav navbar-nav">
          <li><a href="mailto:info@renovaspa.com">info@renovaspa.com</a></li>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e(trans('navbar.lang')); ?> <span class="caret"></span></a>
            <ul class="dropdown-menu dropdown-inverse">
              <li><a href="?lang=es"><?php echo e(trans('navbar.es')); ?></a></li>
              <li><a href="?lang=en"><?php echo e(trans('navbar.en')); ?></a></li>
            </ul>
          </li>
        </ul>
      </div>
  </div>
</nav>
<nav class="navbar navbar-default"  data-spy="affix" data-offset-top="36" style="margin-bottom: <?php echo e((isset($margin) ? '-110px' : '0' )); ?> !important;">
  <div class="container-fluid">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="navbar" aria-expanded="false">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="<?php echo e(URL::to('/')); ?>">
          <img class="img-responsive" style="margin-top: -17px;" src="<?php echo e(URL::to('/')); ?>/images/logo-white-bg.png">
        </a>
      </div>

      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse navbar-right" id="navbar">
        <ul class="nav navbar-nav">
          <li><a href="<?php echo e(route('home.home')); ?>"><?php echo e(trans('navbar.home')); ?> <span class="sr-only">(current)</span></a></li>
          <li><a href="<?php echo e(URL::to('/')); ?>/services"><?php echo e(trans('navbar.bookhere')); ?></a></li>
          <li><a href="<?php echo e(URL::to('/')); ?>/certificates"><?php echo e(trans('navbar.gift_certificates')); ?></a></li>
          <li class="dropdown">
            <a href="#fakelink" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e(trans('navbar.weddings')); ?> <span class="caret"></span></a>
            <ul class="dropdown-menu dropdown-inverse">
              <li><a href="<?php echo e(URL::to('/')); ?>/weddings"><?php echo e(trans('navbar.the_day')); ?></a></li>
              <li><a href="<?php echo e(URL::to('/')); ?>/faq"><?php echo e(trans('navbar.faqs')); ?></a></li>
            </ul>
          </li>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e(trans('navbar.destinations')); ?></a>
            

            <ul class="dropdown-menu dropdown-inverse">
              <?php 
                $navCountries = $dbcontext->getEntityManager()->getRepository("App\Models\Test\CountryModel")->findBy([], ['Name' => 'ASC'])
               ?>
              <?php $__currentLoopData = $navCountries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                <li class="dropdown-submenu">
                <a class="dropdown-action" tabindex="-1" href="#"><?php echo e($country->Name); ?></a>
                <ul class="dropdown-menu dropdown-inverse dropdown-hide">
                  <?php $__currentLoopData = $country->Regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li class="dropdown-submenu">
                      <a href="#" class="dropdown-action dropdown-no-action"><?php echo e($region->Name); ?></a>
                      <ul class="dropdown-menu dropdown-inverse">
                        <?php $__currentLoopData = $region->HotelRegions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotelRegion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                          <li><a href="<?php echo e(URL::to('/')); ?>/hotel/details/<?php echo e($hotelRegion->Hotel->Id); ?>" tabindex="-1" class="dropdown-submenu-item"><?php echo e(strtoupper($hotelRegion->Hotel->Name)); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                      </ul>
                    </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              </ul>
          </li>
          <li>
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e(trans('navbar.about_us')); ?> <span class="caret"></span></a>
            <ul class="dropdown-menu dropdown-inverse">
              <li><a href="<?php echo e(URL::to('/')); ?>/about"><?php echo e(trans('navbar.about_us')); ?></a></li>
              <li><a href="<?php echo e(URL::to('/')); ?>/etiquette"><?php echo e(trans('navbar.spa_etiquette')); ?></a></li>
            </ul>
          <li><a href="<?php echo e(URL::to('/')); ?>/contact"><?php echo e(trans('navbar.contact_us')); ?></a></li>
          <li>
            <?php if(isset($mycart)): ?>
            <a style="font-size: 20px;" href="#fakelink" data-toggle="modal" data-target="#shoppingCartModal">
              <span class="glyphicon glyphicon-shopping-cart"></span>
              <span class="cart-count"><?php echo e(count($mycart->Items)); ?></span>
            </a>
            <?php endif; ?>
          </li>
        </ul>
      </div>

      <!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<?php if(isset($categories)): ?>
<nav class="navbar navbar-inverse">
  <div class="container-fluid" style="margin-top: 9px;">
    <div class="collapse navbar-collapse navbar-right" id="navbar">
        <ul class="nav navbar-nav navbar-categories">
          <?php if(session('reservation_type') == 3): ?>
          <li><a href="<?php echo e(URL::to('/')); ?>/wedding/services">RENOVA WEDDING PACKAGE</a></li>
          <?php endif; ?>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryRegion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <li><a href="<?php echo e(URL::to('/')); ?>/category/<?php echo e($categoryRegion->Category->Id); ?>/services"><?php echo e($categoryRegion->Category->Name); ?></a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
      </div>
  </div>
</nav>

<?php endif; ?>

<?php echo $__env->make('shared.cart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

