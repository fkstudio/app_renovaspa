	

	<?php $__env->startSection('title', 'Shopping cart'); ?>

	<?php $dbcontext = app('App\Database\DbContext'); ?>

	<?php $__env->startSection("content"); ?>
		<div class="container-fluid">
			<?php echo $__env->make('shared._breadcrumps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<hr>
			<h3><?php echo e(trans('titles.my_cart_title')); ?></h3>
			<hr>
			<div class="row">
				<br/>
				<div class="col-md-12">
				    <?php echo $__env->make('shared._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<form action="<?php echo e(URL::to('/') . $action); ?>" method="<?php echo e($method); ?>">
						<table class="table table-responsive">
							<thead>
								<tr>
									<th></th>
									<th><span style="font-weight: normal !important;"><?php echo e(trans("shared.service")); ?></span></th>
									<th><span style="font-weight: normal !important;"><?php echo e(trans('shared.unit_price')); ?></span></th>
									<?php if(session('reservation_type') == 2): ?>
									<th><span style="font-weight: normal !important;"><?php echo e(trans('shared.certificate_numer')); ?></span></th>
									<?php endif; ?>

									<th><span style="font-weight: normal !important;"></span></th>
									<th><span style="font-weight: normal !important;"><?php echo e(trans('shared.quantity')); ?></span></th>
									<th><span style="font-weight: normal !important;"><?php echo e(trans('shared.total')); ?></span></th>
									<th><span style="font-weight: normal !important;"><?php echo e(trans('shared.delete')); ?></span></th>
								</tr>
							</thead>
							<tbody>
								<?php 
									$hotel_id = session('hotel_id');
									$subtotal = 0;
									$total = 0;

									$hotel_region = $dbcontext->getEntityManager()->getRepository("App\Models\Test\HotelRegionModel")->findOneBy([ 'Hotel' => $hotel_id, 'Region' => session('region_id') ]);
								 ?>

								<?php $__currentLoopData = $model->Items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
									<?php 
										$subtotal += $item->Service->getPlanePrice($hotel_region->Hotel->Id) * $item->Quantity;
										$total += $item->Service->getPrice($hotel_region->Hotel->Id) * $item->Quantity;

                         			 ?>	
								<tr>
									<td><img style="max-width: 80px;" src="<?php echo e(URL::to('/')); ?>/images/services/collagen-puls-facial.jpg" class="img-responsive" /> </td>
									<td class="padding-td">
										<input type="hidden" name="id[]" value="<?php echo e($item->Id); ?>" /> 
										<span><?php echo e($item->Service->Name); ?></span>
									</td>
									<td class="padding-td"><?php echo e($country->Currency->Symbol); ?><?php echo e(number_format($item->Service->getPlanePrice($hotel_region->Hotel->Id))); ?></td>
									<?php if(session('reservation_type') == 2): ?>
									<td class="padding-td">Certificate #<?php echo e($item->CertificateNumber); ?></td>
									<?php endif; ?>
									<td class="padding-td">
										<?php if($item->Service->hasDiscount($hotel_region->Hotel->Id)): ?>
										<?php 
											$discount = $item->Service->getDiscount($hotel_region->Hotel->Id)
										 ?>
										<span class="discount"><?php echo e("-".$discount. "% discount"); ?></span>
										<?php endif; ?>

										<?php if($item->Service->hasHotelDiscount($hotel_region->Hotel->Id)): ?>
										<span class="discount">-<?php echo e($hotel_region->Discount); ?>% <?php echo e(trans('shared.online_discount')); ?></span>
										<?php elseif($hotel_region->ActiveDiscount): ?>
										<span class="discount-tached">-<?php echo e($hotel_region->Discount); ?>% <?php echo e(trans('shared.online_discount')); ?></span>
										<?php endif; ?>
									</td>
									<td class="padding-td">
										<input style="width: 80px;margin-top: -5px;" constorls=false type="number" name="quantity[]" value="<?php echo e($item->Quantity); ?>" min=0 class="form-control input-border" />
									</td>
									<td class="padding-td"><?php echo e($country->Currency->Symbol); ?><?php echo e($item->Service->getPrice($hotel_region->Hotel->Id) * $item->Quantity); ?></td>
									<td class="padding-td">
										<a style="margin-top: -6px" href="<?php echo e(URL::to('/')); ?>/shopping/cart/remove/item/<?php echo e($item->Id); ?>" type="button" class="btn btn-danger">X</a>
									</td>
								</tr>
							    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
							</tbody>
						</table>
						<?php if(count($model->Items) <= 0): ?>
						<p style="text-align: center;">There is not item at your cart</p>
						<?php endif; ?>
						<div class="clearfix"></div>
						<div class="col-lg-offset-7 col-lg-5 col-md-offset-5 col-md-7 col-sm-12">
							<div class="row">
								<h3>CART TOTAL</h3>
								<table class="table table-borderless">
									<tbody>
										<tr>
											<td>Subtotal</td>
											<td><?php echo e($country->Currency->Symbol); ?><?php echo e($subtotal); ?></td>
										</tr>
										<?php if($hotel_region->ActiveDiscount): ?>
										<tr>
											<td><span style="font-size: 15px;font-weight: bold;" class="discount">-<?php echo e($hotel_region->Discount); ?>% <?php echo e(trans('shared.online_discount_available')); ?></span></td>
										</tr>
										<?php endif; ?>
										<tr>
											<td><strong>Total</strong></td>
											<td><?php echo e($country->Currency->Symbol); ?><?php echo e($total); ?></td>
										</tr>
									</tbody>
								</table>
								<div class="clearfix"></div>
								<div class="row">
									<div class="col-md-6 col-sm-6 col-xs-12">
										<?php echo e(csrf_field()); ?>

										<a href="<?php echo e(URL::to('/')); ?>/category/<?php echo e($category_id); ?>/services" class="btn btn-default block-button"><?php echo e(trans('shared.back_to_services')); ?></a>
									</div>
									<div class="clearfix visible-xs"></div>
									<br class="visible-xs" />
									<div class="col-md-6 col-sm-6 col-xs-12">
										<?php if($reservationType == 1 || $reservationType == 3): ?> 
											<?php if($total > 0): ?>
												<button type="submit" class="btn btn-primary block-button"><?php echo e(trans('shared.checkout')); ?></button>
											<?php else: ?>
												<button type="button" class="disabled btn btn-primary block-button"><?php echo e(trans('shared.checkout')); ?></button>
											<?php endif; ?>

										<?php elseif($reservationType == 2): ?>
											<?php if($total > 0): ?>
												<button type="submit" class="btn btn-primary block-button"><?php echo e(trans('shared.go_to_gift_registration')); ?></button>
											<?php else: ?>
												<button type="button" class="disabled btn btn-primary block-button"><?php echo e(trans('shared.go_to_gift_registration')); ?></button>
											<?php endif; ?>
										
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>