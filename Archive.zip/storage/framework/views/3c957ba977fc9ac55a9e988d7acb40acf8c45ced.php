<!--footer start from here-->
<div class="clearfix"></div>
<br/>
<footer>
 <br/> 
 <div class="container">
    <div class="row">
      <div class="col-md-4 col-sm-6 footerleft ">
        <h4>CONTACT AND ADDRESS</h4>
        <p><i class="fa fa-map-pin"></i>Plaza progreso - Local 21, Bavaro - Higuey <br/>Republica Dominicana</p>
        <p><i class="fa fa-phone"></i> Phone : (829) 837-1892</p>
        <p><i class="fa fa-envelope"></i> E-mail : info@renovaspa.com</p>
        
      </div>
      <div class="col-md-2 col-sm-6 paddingtop-bottom">
        <h4>LINKS</h4>
        <ul class="footer-ul">
          <li><a href="#"> Career</a></li>
          <li><a href="#"> Privacy Policy</a></li>
          <li><a href="#"> Terms & Conditions</a></li>
        </ul>
      </div>
      <div class="col-md-3 col-sm-6 paddingtop-bottom">
        <h4>RECENTLY SERVICES</h4>
        <div class="post">
          <p>
          	<span>vita cura - facials</span>
          	facebook crack the movie advertisment code:what it means for you
          </p>
          <p>
          	<span>special couple - facials</span>
          	facebook crack the movie advertisment code:what it means for you
          </p>
          <p>
          	<span>manicure - manicure</span>
          	facebook crack the movie advertisment code:what it means for you
          </p>
        </div>
      </div>
      <div class="col-md-3 col-sm-6 paddingtop-bottom">
        <div class="fb-page" data-href="https://www.facebook.com/facebook" data-tabs="timeline" data-height="300" data-small-header="false" style="margin-bottom:15px;" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
          <div class="fb-xfbml-parse-ignore">
            <blockquote cite="https://www.facebook.com/facebook"><a href="https://www.facebook.com/facebook">Facebook</a></blockquote>
            <blockquote cite="https://www.facebook.com/facebook"><a href="https://www.facebook.com/facebook">Twitter</a></blockquote>
            <blockquote cite="https://www.facebook.com/facebook"><a href="https://www.facebook.com/facebook">Pinterest</a></blockquote>
            <blockquote cite="https://www.facebook.com/facebook"><a href="https://www.facebook.com/facebook">Instagram</a></blockquote>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
<!--footer start from here-->

<div class="copyright">
  <div class="container">
    <div class="col-md-4">
      <p>© 2016 - All Rights with renovaspa.com</p>
    </div>
    <div class="col-md-8">
      <ul class="bottom_ul">
        <li><a href="#">renovaspa.com</a></li>
        <li><a href="#">book here</a></li>
        <li><a href="#">gift certificates</a></li>
        <li><a href="#">weddings</a></li>
        <li><a href="#">contact us</a></li>
      </ul>
    </div>
  </div>
</div>