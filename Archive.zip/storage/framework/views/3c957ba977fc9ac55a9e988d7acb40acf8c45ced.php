<!--footer start from here-->
<div class="clearfix"></div>
<br/>
<!--footer start from here-->
<div class="copyright">
  <div class="container-fluid" style="padding-top:50px;padding-bottom: 50px;">
    <div class="row">
      <div class="col-lg-4 ">
        <a target="_blank" href="https://www.facebook.com/RenovaSpa/"><i style="padding-left: 22px;padding-right: 23px" class="social-icon fa fa-facebook"></i></a>
        <a target="_blank" href="https://twitter.com/renovaspas"><i class="social-icon fa fa-twitter"></i></a>
        <a target="_blank" href="https://www.instagram.com/renova.spa/"><i class="social-icon fa fa-instagram"></i></a>
        <a target="_blank" href="https://es.pinterest.com/renovaspa/"><i class="social-icon fa fa-pinterest"></i></a>
      </div>
      <div class="col-lg-8">
        <p class="text-right">
        © All rights Reserved, Renova Spa 2016. Legal advise, Customer Information, Refund and cookies info
        </p>
      </div>
    </div>
  </div>
</div>