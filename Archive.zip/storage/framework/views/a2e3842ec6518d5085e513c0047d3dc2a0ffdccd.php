	

	<?php $__env->startSection('title', 'Services'); ?>

	<?php $dbcontext = app('App\Database\DbContext'); ?>


	<?php 
		$country = $dbcontext->getEntityManager()->getRepository('App\Models\Test\CountryModel')->findOneBy(['Id' => session('country_id')]);
		$hotel_region = $dbcontext->getEntityManager()->getRepository('App\Models\Test\HotelRegionModel')->findOneBy(['Hotel' => session('hotel_id'), 'Region' => session('region_id')]);
	 ?>

	<?php $__env->startSection("content"); ?>
	<div class="container-fluid">
		<?php echo $__env->make('shared._breadcrumps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<hr style="margin-bottom: 0px !important;">
		<?php echo $__env->make('shared._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="row">
			<form action="<?php echo e(URL::to('/')); ?>/payment" method="POST">
				<div class="col-md-6">
					<?php if($model->Type == 2): ?>
					<h3><?php echo e(trans('titles.reservation_checkout_customer_title')); ?></h3>
					<hr>
					<p>We will use this information to send purchase confirmations and certificates to your e-mail address. The billing information may be different.</p>
					<div class="row">
						<div class="col-md-5">
							<div class="form-group">
								<input type="text" required name="customer_first_name" value="<?php echo e($model->CertificateFirstName); ?>" class="form-control input-border" placeholder="* First name/Given name">
							</div>
						</div>
						<div class="col-md-2">
							<input type="text" name="customer_MI" value="<?php echo e($model->CertificateMI); ?>" class="form-control input-border" placeholder="MI">
						</div>
						<div class="col-md-5">
							<div class="form-group">
								<input type="text" required name="customer_last_name" value="<?php echo e($model->CertificateLastName); ?>" class="form-control input-border" placeholder="* Last name/Surname">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<input type="checkbox" name="not_my_info" /> <?php echo e(trans('checkout.not_my_info')); ?>

							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<input type="email" required name="customer_email" value="<?php echo e($model->CertificateEmail); ?>" class="form-control input-border" placeholder="* Email">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<input type="email" required name="customer_email_confirmation" class="form-control input-border" placeholder="* Email confirmation">
							</div>
						</div>
					</div>
					<?php endif; ?>
					<h3><?php echo e(trans('titles.reservation_checkout_left_title')); ?></h3>
					<hr>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<input type="text" value="<?php echo e($model->PaymentInformation->FirstName); ?>" required name="first_name" class="form-control input-border" placeholder="* First name">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<input type="text" required value="<?php echo e($model->PaymentInformation->LastName); ?>" name="last_name" class="form-control input-border" placeholder="* Last name">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<input type="email" required value="<?php echo e($model->PaymentInformation->CustomerEmail); ?>" name="email" class="form-control input-border" placeholder="* email">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<input type="text" required name="country" value="<?php echo e($model->PaymentInformation->CountryName); ?>" class="form-control input-border" placeholder="* country">
							</div>
						</div>

						<div class="col-md-6">
							<div class="form-group">
								<input type="text" name="city" value="<?php echo e($model->PaymentInformation->TownCity); ?>" class="form-control input-border" placeholder="Town/City">
							</div>
						</div>

						<div class="col-md-6">
							<div class="form-group">
								<input type="text" name="post_code" value="<?php echo e($model->PaymentInformation->PostCode); ?>" class="form-control input-border" placeholder="Postcode/Zip">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<input type="number" name="phone_number" value="<?php echo e($model->PaymentInformation->PhoneNumber); ?>" class="form-control input-border" placeholder="Phone number">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<input type="text" name="company_name" value="<?php echo e($model->PaymentInformation->CompanyName); ?>" class="form-control input-border" placeholder="Company name">
							</div>
						</div>
						<div class="clearfix"></div>
						<div class="col-md-12">
							<div class="form-group">
								<input type="text" name="street_address" value="<?php echo e($model->PaymentInformation->StreetAddress); ?>" class="form-control input-border" placeholder="StreetAddress">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<input type="text" name="apartment_unit" value="<?php echo e($model->PaymentInformation->ApartmentUnit); ?>" class="form-control input-border" placeholder="Apartment, suit, unit, etc (optional)">
							</div>
						</div>

					</div>
				</div>
				<div class="col-md-6">
					<h3><?php echo e(trans('titles.reservation_checkout_right_title')); ?></h3>
					<hr>
					<?php 
						$hotel_id = $hotel_region->Hotel->Id;
					 ?>
					<?php if($model->Type == 1): ?>
						<?php $__currentLoopData = $model->ServicesDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<div class="col-md-12">
							<div class="row">
								<h5><strong>1 <?php echo e($detail->Service->Name); ?></strong> - <?php echo e(trans("shared.cabin_type")); ?> ( <?php echo e($detail->Cabin->Name); ?> )</h5>
								<?php if($detail->Service->hasDiscount($hotel_id)): ?>
									<?php 
										$discount = $detail->Service->getDiscount($hotel_id)
									 ?>
									<span class="discount"><?php echo e("-".$discount. "% ".trans('shared.discount')); ?></span>
									<?php endif; ?>

									<?php if($detail->Service->hasHotelDiscount($hotel_id)): ?>
									<span class="discount">-<?php echo e($hotel_region->Discount); ?>% <?php echo e(trans('shared.online_discount')); ?></span>
									<?php elseif($hotel_region->ActiveDiscount): ?>
									<span class="discount-tached">-<?php echo e($hotel_region->Discount); ?>% <?php echo e(trans('shared.online_discount')); ?></span>
								<?php endif; ?>
								<br/>
								<span><?php echo e(trans('checkout.booked_to')); ?> <?php echo e($detail->PreferedDate->format('d/m/Y')); ?> <?php echo e(trans('checkout.at_time')); ?> <?php echo e($detail->PreferedTime->format('h:m a')); ?>, <?php echo e($detail->CustomerName); ?></span>
								<br/>
								<span><?php echo e(trans('shared.price')); ?>: <?php echo e($country->Currency->Symbol.number_format($detail->Service->getPlanePrice($hotel_id), 2)); ?></span>
								<br/>
								<span><?php echo e(trans('shared.final_price')); ?>: <strong><?php echo e($country->Currency->Symbol.number_format($detail->Service->getPrice($hotel_id), 2)); ?></strong></span>
							</div>
						</div>
						<div class="clearfix"></div>
						<hr style="border-color:#5fc7ae;" />
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					<?php elseif($model->Type == 2): ?>
						<?php $__currentLoopData = $model->CertificateDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<div class="col-md-2">
							<span class="glyphicon glyphicon-gift gift-icon"></span>
						</div>
						<div class="col-md-10">
							<div class="row">
								<h5 style="color:#5fc7ae;"><strong>Gift certificate #<?php echo e($key + 1); ?></strong></h5>
								<?php if($detail->Type == 2): ?>
								<span>(Value based)</span>
								<br/>
								<?php endif; ?>
								<span>From <?php echo e($detail->FromCustomerName); ?> to <?php echo e($detail->ToCustomerName); ?></span>
								<?php if($detail->Type == 1): ?>
								<br/>
								<span>Services:</span>
									<ul style="list-style: none;margin-bottom: 0px;">
										<?php $__currentLoopData = $detail->CertificateDetailServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificateDetailService): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
										<li>- <?php echo e($certificateDetailService->Service->Name); ?></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
									</ul>
								<?php else: ?>
								<br/>
								<?php endif; ?>
								<span><?php echo e(trans('checkout.message')); ?>: <?php echo e($detail->Message); ?></span>
								<br/>
								<span><?php echo e(trans('checkout.value')); ?>: <strong><?php echo e($country->Currency->Symbol.$detail->Value); ?></strong></span>
							</div>
						</div>
						<div class="clearfix"></div>
						<hr style="border-color:#5fc7ae;" />
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					<?php endif; ?>
					<table class="table table-borderless">
						<h3><?php echo e(trans('titles.cart_total')); ?></h3>
						<tbody style="font-size: 20px;">
							<tr>
								<td>Subtotal</td>
								<td><?php echo e($country->Currency->Symbol); ?><?php echo e(number_format($model->Subtotal, 2)); ?></td>
							</tr>
							<?php if($hotel_region->ActiveDiscount): ?>
							<tr>
								<td><span style="font-size: 15px;font-weight: bold;" class="discount">-<?php echo e($hotel_region->Discount); ?>% <?php echo e(trans('shared.online_discount_available')); ?></span></td>
							</tr>
							<?php endif; ?>
							<tr>
								<td><strong>Total</strong></td>
								<td><?php echo e($country->Currency->Symbol); ?><?php echo e(number_format($model->Total, 2)); ?></td>
							</tr>
						</tbody>
					</table>
					<div class="col-md-6">
						<input type="radio" name="payment_method" value="<?php echo e($paymentMethods[0]->Id); ?>" /> <?php echo e($paymentMethods[0]->Name); ?>

						<img style="width: 100px; float:right; margin-top: -15px" class="img-responsive" src="<?php echo e(URL::to('/')); ?>/images/paypal.png" />
					</div>
					<div class="col-md-6">
						<input type="radio" checked name="payment_method" value="<?php echo e($paymentMethods[1]->Id); ?>" /> <?php echo e($paymentMethods[1]->Name); ?>

						<img style="width: 100px; float:right; margin-top: -5px" class="img-responsive" src="<?php echo e(URL::to('/')); ?>/images/visamastercard.png" />
					</div>
					<div class="clearfix"></div>
					<br/>
					<div class="col-md-12">
						<?php echo e(csrf_field()); ?>

						<button type="submit" class="btn btn-primary btn-block"><?php echo e(trans('checkout.place_order')); ?></button>
					</div>
				</div>
			</form>
		</div>
	</div>
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection("scripts"); ?>
	<script>
		
		$(document).on('ready', function(){
			$("#showContentButton").click(function(){
				preventDefault();
				$("#contentPaymentInfo").removeClass("hidden");
			})
		})
	</script>
	<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>