<?php $__env->startSection('title', 'Regions'); ?>

<?php $__env->startSection("content"); ?>
<div class="container-fluid">
	<?php echo $__env->make('shared._breadcrumps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<hr>
	<div class="row">
		<?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<?php 
			$photoPath = '/noimage.jpg';

			if($region->Photo != null)
			{
				$photoPath = '/regions/region-'.$region->Id.'/'.$region->Photo->Path;
			}

		 ?>
		<a style="font-size: 30px;color:white;" href="<?php echo e(URL::to('/')); ?>/region/<?php echo e($region->Id); ?>/hotels">
		    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
		    	<div style="background: url(<?php echo e(URL::to('/images') . $photoPath); ?>);background-size: cover;" class="col-md-12 block-content" >
					<span><?php echo e($region->Name); ?></span>
				</div>
		    </div>
		</a>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>