<?php if(isset($breadcrumps)): ?>
<p class="breadcrumps">
	<?php 
		$reservation_type = session('reservation_type');
		$label = "";
		$label_url = "";

		switch($reservation_type){
			case 1:
				$label = "SERVICES";
				$label_url = "/select/services";
				break;
			case 2:
				$label = "CERTIFICATES";
				$label_url = "/select/certificates";
				break;
			case 3:
				$label = "WEDDINGS";
				$label_url = "/select/weddings";
				break;
		}

	 ?>
	
	<a href="<?php echo e(URL::to('/')); ?>"> HOME</a>
	<a href="<?php echo e(URL::to('/') . $label_url); ?>"> / <?php echo e($label); ?></a>
	<?php $__currentLoopData = $breadcrumps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<?php 
			if($value == "#fakelink")
				$newUrl = "#fakelink";
			else
				$newUrl = URL::to('/') . $value;
		 ?>
		<a href="<?php echo e($newUrl); ?>"> / <?php echo e($key); ?></a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</p>
<?php endif; ?>