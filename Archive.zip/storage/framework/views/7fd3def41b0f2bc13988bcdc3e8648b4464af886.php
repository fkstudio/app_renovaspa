<?php $__env->startSection('title', 'Regions'); ?>

<?php 
	$reservationType = session('reservation_type');
	$bgs[1] = "bookhere-bg.jpg";
	$bgs[2] = "certificates-bg.jpg";
	$bgs[3] = "weddings-bg.jpg";
 ?>

<?php $__env->startSection("content"); ?>
<div id="vue-app" class="container-fluid-full" style="background: url(<?php echo e(URL::to('/')); ?>/images/<?php echo e($bgs[$reservationType]); ?>);background-size: cover;background-position: center center;padding-top: 300px;padding-bottom: 250px;">
	<div class="container-fluid-full" style="background: #F5F5F5;">
		<br/>
		<?php if($reservationType == 1): ?>
		<h2 style="color: #5fc7ae;" class="text-center"><?php echo e(trans('titles.book_your_treatment')); ?></h2>
		<?php elseif($reservationType == 2): ?>
		<h2 style="color: #5fc7ae;" class="text-center"><?php echo e(trans('titles.treat_someone')); ?></h2>
		<?php else: ?>
		<h2 style="color: #5fc7ae;" class="text-center"><?php echo e(trans('titles.the_day')); ?></h2>
		<?php endif; ?>
		<br/>
		<form action="<?php echo e(URL::to('/')); ?>/reservation/select/book" method="POST" class="form-inline text-center">
			<div class="form-group text-left">
				<label class="custom-label"><?php echo e(trans('shared.country')); ?></label>
				<div class="clearfix"></div>
				<select v-model='country_id' id='country_id' name="country_id" v-on:change='getRegions()' class="form-control custom-select">
					<?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<option value="<?php echo e($country->Id); ?>"><?php echo e($country->Name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</select>
			</div>

			<div class="form-group text-left">
				<label class="custom-label"><?php echo e(trans('shared.destination')); ?></label>
				<div class="clearfix"></div>
				<select v-model='region_id' v-on:change='getHotels()' id="region_id" name='region_id' class="form-control custom-select">
                </select>
			</div>
			
			<div class="form-group text-left">
				<label class="custom-label"><?php echo e(trans('shared.hotel')); ?></label>
				<div class="clearfix"></div>
				<select v-model='hotel_id' v-on:change='getWeddingPackages()' id="hotel_id" name='hotel_id' class="form-control custom-select">
                </select>
			</div>

			<?php if($reservationType == 3): ?>
			<div class="form-group text-left">
				<label class="custom-label"><?php echo e(trans('shared.wedding_package')); ?></label>
				<div class="clearfix"></div>
				<select v-model='wedding_package_id' id="wedding_package_id" name='wedding_package_id' class="form-control custom-select">
                </select>
			</div>
			<?php endif; ?>

			<div class="form-group">
				<label class="custom-label"></label>
				<div class="clearfix"></div>
				<?php echo e(csrf_field()); ?>

				
				<?php if($reservationType == 1): ?>
				<input type="hidden" name="reservation_type" value="1" />
				<?php elseif($reservationType == 2): ?>
				<input type="hidden" name="reservation_type" value="2" />
				<?php else: ?>
				<input type="hidden" name="reservation_type" value="3" />
				<?php endif; ?>
				<button type="submit" class="btn-confirm-book btn btn-primary" style="margin-top: 10px;"><?php echo e(trans('shared.confirm')); ?></button>
			</div>
		</form>
		<br/>
		<br/>
		<br/>
	</div>

	<p class="discount-message-reservation">
		<?php if(session('reservation_type') == 2): ?>
			<?php echo e(trans('bookhere.online_certificate_discount_reservation')); ?>

		<?php else: ?>
			<?php echo e(trans('bookhere.online_discount_reservation')); ?>

		<?php endif; ?>
	</p>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(URL::to('/js')); ?>/vuejs.js"></script>
<script>

	var vue = new Vue({
	    el: '#vue-app',
	    data: {
	        country_id: undefined,
	        region_id: undefined,
	        hotel_id: undefined,
	        wedding_package_id: undefined,
	        regions: [],
	        hotels: []
	    },
	    ready: function(){
	        this.getCountries();
	    },
	    computed: {

	    },
	    methods: {
	        getRegions: function(){
	            var self = this;
	            
	            $.ajax({
	                url: '<?php echo e(URL::to("/")); ?>/async/region/by/country/' + self.country_id,
	                method: 'GET'
	            }).done(function(response){
	                var regionList = JSON.parse(response);
	                var regionSelect = $("#region_id");
	                regionSelect.html("<option></option>");
	                $("#hotel_id").html("<option></option>");
	                $("#wedding_package_id").html("<option></option>");

	                for(var i in regionList){
	                    regionSelect.append("<option value='"+regionList[i].id+"'>"+regionList[i].name+"</option>");
	                }
	            });
	        },
	        getHotels: function(){
	            var self = this;

	            $.ajax({
	                url: '<?php echo e(URL::to("/")); ?>/async/hotel/by/region/' + self.region_id,
	                method: 'GET'
	            }).done(function(response){
	                var hotelList = JSON.parse(response);
	                var hotelSelect = $("#hotel_id");
	                $("#wedding_package_id").html("<option></option>");

	                for(var i in hotelList){
	                    hotelSelect.append("<option value='"+hotelList[i].id+"'>"+hotelList[i].name+"</option>");
	                }
	            });
	        },
	        getWeddingPackages: function(){
	            var self = this;

	            $.ajax({
	                url: '<?php echo e(URL::to("/")); ?>/async/wedding/packages/by/hotel/' + self.hotel_id,
	                method: 'GET'
	            }).done(function(response){
	                var weddingPackages = JSON.parse(response);

	                console.log(weddingPackages);
	                
	                var pacakgeSelect = $("#wedding_package_id");
	                pacakgeSelect.html("");
	                pacakgeSelect.append("<option value='nopackage'>No packages</option>");

	                for(var i in weddingPackages){
	                    pacakgeSelect.append("<option value='"+weddingPackages[i].id+"'>"+weddingPackages[i].name+"</option>");
	                }
	            });
	        }
	    }
	});
</script>
<?php $__env->stopSection(); ?>

   
<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>