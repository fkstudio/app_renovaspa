<?php $__env->startSection('title', 'Regions'); ?>

<?php $__env->startSection("content"); ?>
<div class="container-fluid">
	<?php echo $__env->make('shared._breadcrumps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<hr>
	<div class="row">
		
	
	<?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<a style="font-size: 30px;color:white;" href="<?php echo e(URL::to('/')); ?>/country/<?php echo e($country->Id); ?>/regions">
		    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
		    	<div style="background: url(<?php echo e(URL::to('/images')); ?>/countries/country-<?php echo e($country->Id); ?>/<?php echo e($country->Photo->Path); ?>);background-size: cover;" class="col-md-12 block-content" >
					<span><?php echo e($country->Name); ?>	</span>
				</div>
		    </div>
		</a>
		<?php break; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

   
<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>