<?php $dbcontext = app('App\Database\DbContext'); ?>



<?php 

$categories = $dbcontext->getEntityManager()->getRepository("App\Models\Test\CategoryCountryModel")
                                                  ->findBy(["Country" => session('country_id')], ["Order" => "DESC"]);
$hotel_region = $dbcontext->getEntityManager()->getRepository("App\Models\Test\HotelRegionModel")->findOneBy([ 'Hotel' => session('hotel_id'), 'Region' => session('region_id') ]);
 ?>

<?php $__env->startSection('title', 'Wedding services'); ?>


<?php $__env->startSection("content"); ?>
<div class="container-fluid">
	<?php echo $__env->make('shared._breadcrumps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<hr>
	<?php echo $__env->make('shared._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="row">
		<br/>
		<div class="col-md-5">
			<img style="margin: 0 auto;" src="<?php echo e(URL::to('/')); ?>/images/renova_wedding_package.jpg" class="img-responsive" />
			<br class="hidden-lg" />
		</div>
		<div class="col-md-7">
			<h4><?php echo e(trans('titles.service_list_title')); ?></h5>
			<br/>
			<form action="<?php echo e(URL::to('/')); ?>/cart/add/services" method="POST">
				<?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryHotel): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<h5><?php echo e($categoryHotel->WeddingPackageCategory->Name); ?></h5>
					<p><?php echo e($categoryHotel->WeddingPackageCategory->Description); ?></p>
					<?php 

						$packageRelations = $dbcontext->getEntityManager()->getRepository("App\Models\Test\WeddingPackageCategoryRelationModel")
                                                  ->findBy(['WeddingPackageCategoryHotel' => $categoryHotel->Id])
					 ?>
					<?php $__currentLoopData = $packageRelations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkey => $package): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<div class="package-info row">
						<div class="col-md-8" style="padding-top: 10px;">
							<input type="hidden" value="<?php echo e($package->Id); ?>" name="pacakge_relation_id[]" />
							<strong><?php echo e($package->WeddingPackage->Name); ?></strong>
							<a style="cursor: pointer;" data-toggle="collapse" data-target="#package-<?php echo e($pkey); ?>">+Info</a>
						</div>
						<div class="col-md-2" style="padding-top: 10px;">
							<span style="font-size: 18px;" class="float-right"><?php echo e($country->Currency->Symbol.number_format($package->getPrice(), 2)); ?></span><span style="font-size: 12px;"><?php echo e($country->Currency->Name); ?></span>
						</div>
						<div class="col-md-2">
							<input style="max-width: 70px !important;" type="number" value='0' name="quantity[]" class="form-control input-border" />
						</div>
						<div class="col-md-12">
							<div id="package-<?php echo e($pkey); ?>" class="collapse">
								<p><?php echo e($package->WeddingPackage->Description); ?></p>
								<p><strong>Included services:</strong></p>
								<ul>
									<?php $__currentLoopData = $package->WeddingPackage->WeddingPackageServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packageService): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
										<li><?php echo e($packageService->Service->Name); ?></li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
								</ul>
								<?php if(count($package->WeddingPackage->WeddingPackageServices) <= 0): ?>
								<p>There is not services added to this package</p>
								<?php endif; ?>
								<br/>
							</div>
						</div>	
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				<div class="clearfix"></div>
				<br/>
				<div class="form-group">
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
							<?php echo e(csrf_field()); ?>

							<button type="submit" name="weddings" class="btn btn-interline block-button"><?php echo e(trans('shared.add_to_cart')); ?></button>	
						</div>
						<br class="visible-xs" />
						<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
							<a href="<?php echo e(URL::to('/shopping/cart')); ?>" class="btn btn-default block-button"><?php echo e(trans('shared.go_to_cart')); ?></a>
						</div>
					</div>
				</div>
			</form>
			
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>