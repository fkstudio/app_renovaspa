<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection("content"); ?>
	<div class="container-fluid">
		<?php echo $__env->make('shared._breadcrumps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<hr>
		<?php echo $__env->make('shared._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="row">
			<?php if(session('reservation_type') == 3): ?>
			<a style="font-size: 30px;color:white;" href="<?php echo e(URL::to('/')); ?>/wedding/services">
			    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
			    	<div style="background: url(<?php echo e(URL::to('/')); ?>/images/renova_wedding_package.jpg);background-size: cover;" class="col-md-12 block-content" >
						<span>Renova Wedding packages</span>
					</div>
			    </div>
			</a>
			<?php endif; ?>
			<?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryCountry): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<?php if($categoryCountry->Category->IsDeleted == false): ?>
				
					<?php 

					$photoPath = '/noimage.jpg';

					if($categoryCountry->Category->Photo != null)
					{
						$photoPath = '/categories/category-'.$categoryCountry->Category->Id.'/'.$categoryCountry->Category->Photo->Path;
					}
					
					if($categoryCountry->IsSpecial == true && $categoryCountry->SpecialBeginDate != null && $categoryCountry->SpecialEndDate != null)
					{
						$currentDate = new DateTIme("now");

						if($currentDate >= $categoryCountry->SpecialBeginDate && $currentDate <= $categoryCountry->SpecialEndDate)
						{

						}
						else {
							continue;
						}
					}

					 ?>

					<a style="font-size: 30px;color:white;" href="<?php echo e(URL::to('/')); ?>/category/<?php echo e($categoryCountry->Category->Id); ?>/services">
					    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
					    	<div style="background: url(<?php echo e(URL::to('/images') .$photoPath); ?>);background-size: cover;" class="col-md-12 block-content" >
								<span><?php echo e($categoryCountry->Category->Name); ?></span>
							</div>
					    </div>
					</a>
				<?php endif; ?>
	    	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	    </div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>