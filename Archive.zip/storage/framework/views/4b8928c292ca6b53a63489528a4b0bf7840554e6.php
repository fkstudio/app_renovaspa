<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection("content"); ?>
	<div class="container-fluid">
		<?php echo $__env->make('shared._breadcrumps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<hr>
		<?php echo $__env->make('shared._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="row">
			<?php if(session('reservation_type') == 3): ?>
			<a style="font-size: 30px;color:white;" href="<?php echo e(URL::to('/')); ?>/wedding/services">
			    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
			    	<div style="background: url(<?php echo e(URL::to('/')); ?>/images/renova_wedding_package.jpg);background-size: cover;" class="col-md-12 block-content" >
						<span>Renova Wedding packages</span>
					</div>
			    </div>
			</a>
			<?php endif; ?>
			<?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryRegion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<a style="font-size: 30px;color:white;" href="<?php echo e(URL::to('/')); ?>/category/<?php echo e($categoryRegion->Category->Id); ?>/services">
			    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
			    	<div style="background: url(<?php echo e(URL::to('/')); ?>/images/categories/category-<?php echo e($categoryRegion->Category->Id); ?>/<?php echo e($categoryRegion->Category->Photo->Path); ?>);background-size: cover;" class="col-md-12 block-content" >
						<span><?php echo e($categoryRegion->Category->Name); ?></span>
					</div>
			    </div>
			</a>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	    </div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>