<?php $__env->startSection('title', 'Hotels'); ?>

<?php $__env->startSection("content"); ?>
<div class="container-fluid">
	<?php echo $__env->make('shared._breadcrumps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<hr>
	<div class="row">
		<?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotelRegion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		    <?php 
		    	$url = "";
			    
			    if ($reservationType == 2){
			    	$url = "/certificate/options/".$hotelRegion->Hotel->Id;
			    }
			    else {
			    	$url = "/hotel/".$hotelRegion->Hotel->Id."/categories";
			    }
			    
			    $photoPath = '/noimage.jpg';

				if($region->Photo != null)
				{
					$photoPath = '/hotels/hotel-'.$hotelRegion->Hotel->Id.'/'.$hotelRegion->Hotel->getProfile();
				}
		     ?>

	    <a style="font-size: 30px;color:white;" href="<?php echo e(URL::to('/').$url); ?>">
		    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
		    	<div style="background: url(<?php echo e(URL::to('/images') . $photoPath); ?>);background-size: cover;" class="col-md-12 block-content" >
					<span><?php echo e($hotelRegion->Hotel->Name); ?></span>
				</div>
		    </div>
		</a>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>

    
<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>