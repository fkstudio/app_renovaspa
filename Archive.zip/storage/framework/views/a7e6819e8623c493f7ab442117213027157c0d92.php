	

	<?php $__env->startSection('title', 'Voucher'); ?>

	<?php $__env->startSection("content"); ?>
		<?php echo $__env->make('wedding._quotation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
		<div class="clearfix"></div>
		<p class="text-center"><a href="<?php echo e(URL::to('/')); ?>">GO TO HOME</a></p>
	<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/baseLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>